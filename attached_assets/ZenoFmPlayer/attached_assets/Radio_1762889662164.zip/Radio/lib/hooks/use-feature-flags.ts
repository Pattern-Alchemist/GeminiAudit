'use client';

import useSWR from 'swr';

interface FeatureFlag {
  enabled: boolean;
  meta?: any;
}

interface FeatureFlagsResponse {
  flags: Record<string, FeatureFlag>;
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export function useFeatureFlags() {
  const { data, error, mutate } = useSWR<FeatureFlagsResponse>(
    '/api/feature-flags',
    fetcher,
    {
      revalidateOnFocus: false,
      revalidateOnReconnect: false,
      dedupingInterval: 60000,
    }
  );

  const isEnabled = (flagKey: string): boolean => {
    return data?.flags?.[flagKey]?.enabled ?? false;
  };

  const getFlag = (flagKey: string): FeatureFlag | null => {
    return data?.flags?.[flagKey] ?? null;
  };

  const toggleFlag = async (flagKey: string, enabled: boolean) => {
    try {
      const response = await fetch('/api/feature-flags', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: flagKey, enabled }),
      });

      if (!response.ok) throw new Error('Failed to update flag');

      await mutate();
      return true;
    } catch (error) {
      console.error('Error toggling flag:', error);
      return false;
    }
  };

  return {
    flags: data?.flags ?? {},
    isLoading: !error && !data,
    isError: error,
    isEnabled,
    getFlag,
    toggleFlag,
    refresh: mutate,
  };
}
