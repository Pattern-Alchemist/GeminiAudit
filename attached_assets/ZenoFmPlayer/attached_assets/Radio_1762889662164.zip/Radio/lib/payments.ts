import { z } from 'zod';
import { getPaymentConfiguration } from './env';

export const PayPalOrderSchema = z.object({
  intent: z.literal('CAPTURE'),
  purchase_units: z
    .array(
      z.object({
        reference_id: z.string(),
        amount: z.object({
          currency_code: z.string(),
          value: z.string()
        })
      })
    )
    .min(1)
});

export type PayPalOrder = z.infer<typeof PayPalOrderSchema>;

export const UpiIntentSchema = z.object({
  amount: z.number().positive(),
  currency: z.string().default('INR'),
  upiId: z.string().min(5),
  purpose: z.string()
});

export function buildUpiUri(data: z.infer<typeof UpiIntentSchema>) {
  const params = new URLSearchParams({
    pa: data.upiId,
    pn: 'AstroKalki',
    am: data.amount.toFixed(2),
    cu: data.currency,
    tn: data.purpose
  });

  return `upi://pay?${params.toString()}`;
}

type PaymentAttempt = {
  channel: 'paypal' | 'upi';
  reference: string;
  amount: number;
  currency: string;
  status: string;
  payload?: unknown;
};

export function logPaymentAttempt(attempt: PaymentAttempt) {
  const config = getPaymentConfiguration();
  const enriched = {
    ...attempt,
    timestamp: new Date().toISOString(),
    integrationsEnabled: config.enabled
  };

  console.info('payment_attempt', enriched);
  return enriched;
}

export function resolveActivePaymentChannels() {
  const config = getPaymentConfiguration();
  return {
    paypal: Boolean(config.paypalUrl),
    upi: Boolean(config.upiId)
  };
}
