const services = {
  openrouter: {
    keys: ['OPENROUTER_API_KEY', 'OPENROUTER_API_BASE'],
    label: 'OpenRouter'
  },
  gemini: {
    keys: ['GEMINI_API_KEY'],
    label: 'Gemini'
  },
  cal: {
    keys: ['CAL_COM_API_KEY', 'CAL_COM_LINK'],
    label: 'Cal.com'
  },
  resend: {
    keys: ['RESEND_API_KEY'],
    label: 'Resend Email'
  },
  livekit: {
    keys: ['LIVEKIT_URL', 'LIVEKIT_API_KEY', 'LIVEKIT_API_SECRET', 'NEXT_PUBLIC_LIVEKIT_URL'],
    label: 'LiveKit'
  },
  payments: {
    keys: ['UPI_ID', 'PAYPAL_URL'],
    label: 'Payments'
  }
} as const;

type ServiceKey = keyof typeof services;

type IntegrationConfig = {
  service: string;
  missing: string[];
};

export function getIntegrationWarnings(): IntegrationConfig[] {
  const warnings: IntegrationConfig[] = [];

  (Object.keys(services) as ServiceKey[]).forEach((key) => {
    const definition = services[key];
    const missing = definition.keys.filter((envKey) => !process.env[envKey]);

    if (missing.length > 0) {
      warnings.push({
        service: definition.label,
        missing
      });
    }
  });

  return warnings;
}

export function getOpenRouterConfig() {
  const apiKey = process.env.OPENROUTER_API_KEY;
  const apiBase = process.env.OPENROUTER_API_BASE;
  return {
    apiKey,
    apiBase,
    enabled: Boolean(apiKey && apiBase)
  };
}

export function getGeminiConfig() {
  const apiKey = process.env.GEMINI_API_KEY;
  return {
    apiKey,
    enabled: Boolean(apiKey)
  };
}

export function getCalComConfig() {
  const apiKey = process.env.CAL_COM_API_KEY;
  const bookingLink = process.env.CAL_COM_LINK;
  return {
    apiKey,
    bookingLink,
    enabled: Boolean(apiKey && bookingLink)
  };
}

export function getResendConfig() {
  const apiKey = process.env.RESEND_API_KEY;
  return {
    apiKey,
    enabled: Boolean(apiKey)
  };
}

export function getLiveKitConfig() {
  const url = process.env.LIVEKIT_URL;
  const apiKey = process.env.LIVEKIT_API_KEY;
  const apiSecret = process.env.LIVEKIT_API_SECRET;
  const publicUrl = process.env.NEXT_PUBLIC_LIVEKIT_URL;

  return {
    url,
    apiKey,
    apiSecret,
    publicUrl,
    enabled: Boolean(url && apiKey && apiSecret && publicUrl)
  };
}

export function getPaymentConfiguration() {
  const upiId = process.env.UPI_ID;
  const paypalUrl = process.env.PAYPAL_URL;

  return {
    upiId,
    paypalUrl,
    enabled: Boolean(upiId && paypalUrl)
  };
}
