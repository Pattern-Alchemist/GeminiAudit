import { getCalComConfig } from './env';

type ConsultationTier = 'flash-q' | 'karma-decode' | 'dharma-alignment';

type BookingPayload = {
  tier: ConsultationTier;
  email: string;
  name: string;
};

const tierPaths: Record<ConsultationTier, string> = {
  'flash-q': 'flash-q',
  'karma-decode': 'karma-decode',
  'dharma-alignment': 'dharma-alignment'
};

export function createConsultationLink(payload: BookingPayload) {
  const cal = getCalComConfig();

  if (!cal.enabled || !cal.bookingLink) {
    return null;
  }

  const suffix = tierPaths[payload.tier] ?? 'intro';
  const params = new URLSearchParams({
    name: payload.name,
    email: payload.email
  });

  return `${cal.bookingLink}/${suffix}?${params.toString()}`;
}
