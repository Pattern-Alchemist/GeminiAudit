export function cn(...inputs: Array<string | undefined | null | false>) {
  return inputs.filter(Boolean).join(' ');
}

export const accentGradient = 'from-cosmic-copper to-cosmic-copperBright';
