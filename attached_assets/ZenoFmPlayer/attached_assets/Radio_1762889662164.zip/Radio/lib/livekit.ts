import { getLiveKitConfig } from './env';
import crypto from 'node:crypto';

type RoomOptions = {
  name?: string;
};

export function createLiveKitToken(options: RoomOptions = {}) {
  const livekit = getLiveKitConfig();

  if (!livekit.enabled || !livekit.apiKey || !livekit.apiSecret) {
    return null;
  }

  const roomName = options.name ?? `karma-room-${Date.now()}`;
  const token = crypto.createHmac('sha256', livekit.apiSecret).update(roomName).digest('hex');

  return {
    token,
    roomName,
    url: livekit.publicUrl
  };
}
