import { getOpenRouterConfig, getGeminiConfig } from './env';

export interface KarmaInput {
  birthDate: string;
  birthTime: string;
  birthPlace: string;
  timezone?: string;
  additionalContext?: Record<string, any>;
}

export interface KarmaOutput {
  success: boolean;
  data?: any;
  error?: string;
  cached?: boolean;
  demoMode?: boolean;
}

export type KarmaTool = 'dna' | 'debts' | 'impacts' | 'radar' | 'bond' | 'scan';

const SYSTEM_PROMPTS: Record<KarmaTool, string> = {
  scan: `You are a Vedic astrology expert specializing in karma analysis. Based on birth data, provide a quick 90-second karmic insight covering: 1) Primary karmic pattern, 2) One immediate action to take, 3) One thing to avoid this week. Keep it concise and actionable.`,
  
  dna: `You are a master of Vedic astrology and karma analysis. Analyze the birth chart to reveal the person's KARMIC DNA - their core patterns, gifts, challenges, and soul purpose. Structure your response as:
1. CORE PATTERN: The fundamental karmic signature
2. GIFTS: Natural talents from past karma
3. CHALLENGES: Karmic debts to resolve
4. SOUL PURPOSE: Why they incarnated
5. IMMEDIATE ACTION: One thing to do this month
Keep it profound yet practical.`,

  debts: `You are a Vedic karma specialist. Identify the person's KARMIC DEBTS based on their birth chart. For each debt category (ancestral, relationship, career, health, spiritual), assess:
- Debt severity (0-10)
- Manifestation patterns
- Root cause
- Clearing ritual
- Timeline for resolution
Focus on the top 3 most urgent debts.`,

  impacts: `You are a Vedic timing expert. Analyze the next 90 days and identify KARMIC IMPACT WINDOWS - periods when specific actions will have amplified results. Structure as:
- Date range
- Impact type (opportunity/caution/rest)
- Best actions to take
- What to avoid
- Energy level (1-10)
Provide 5-7 windows covering the full 90-day period.`,

  radar: `You are a Vedic house and chakra expert. Analyze the birth chart for ENERGY LEAKS across 12 life areas (houses). For each leaking area, provide:
- Area name (Career, Relationships, Health, etc.)
- Leak severity (0-10)
- Symptom manifestation
- Root cause (planetary/nodal)
- Plug ritual (practical action)
Present as a radar chart data: 6 dimensions with scores 0-10.`,

  bond: `You are a relationship karma specialist. Analyze karmic BONDS and BOUNDARIES in the person's life. Identify:
- Toxic bonds to release (who and why)
- Healthy boundaries to enforce (where and how)
- Soul contracts to honor (with whom)
- Relationship scripts (3 conversation frameworks)
Provide practical, compassionate guidance for each bond type.`
};

const USER_PROMPT_TEMPLATES: Record<KarmaTool, (input: KarmaInput) => string> = {
  scan: (input) => `Birth Date: ${input.birthDate}\nBirth Time: ${input.birthTime}\nBirth Place: ${input.birthPlace}\n\nProvide a 90-second karmic quick scan.`,
  
  dna: (input) => `Birth Date: ${input.birthDate}\nBirth Time: ${input.birthTime}\nBirth Place: ${input.birthPlace}\n\nReveal my complete karmic DNA.`,
  
  debts: (input) => `Birth Date: ${input.birthDate}\nBirth Time: ${input.birthTime}\nBirth Place: ${input.birthPlace}\n\nIdentify my top 3 karmic debts and how to clear them.`,
  
  impacts: (input) => `Birth Date: ${input.birthDate}\nBirth Time: ${input.birthTime}\nBirth Place: ${input.birthPlace}\nTimezone: ${input.timezone || 'UTC'}\n\nMap my karmic impact windows for the next 90 days.`,
  
  radar: (input) => `Birth Date: ${input.birthDate}\nBirth Time: ${input.birthTime}\nBirth Place: ${input.birthPlace}\n\nScan my energy field for leaks across all 12 life areas.`,
  
  bond: (input) => `Birth Date: ${input.birthDate}\nBirth Time: ${input.birthTime}\nBirth Place: ${input.birthPlace}\n\nAnalyze my relationship karma - bonds to release and boundaries to set.`
};

const DEMO_RESPONSES: Record<KarmaTool, any> = {
  scan: {
    pattern: "Saturn Return Activation",
    action: "Complete one unfinished project from the past",
    avoid: "Starting new commitments before finishing old ones",
    energy: 7
  },
  
  dna: {
    corePattern: "Builder of Sacred Structures",
    gifts: ["Strategic thinking", "Patience", "Systems design"],
    challenges: ["Perfectionism", "Fear of completion", "Ancestral business karma"],
    soulPurpose: "To create lasting systems that serve collective evolution",
    immediateAction: "Document your vision in writing - make it real"
  },
  
  debts: [
    {
      category: "ancestral",
      severity: 8,
      manifestation: "Inherited business patterns, fear of success",
      rootCause: "Unfinished family business from 3 generations ago",
      ritual: "Weekly ancestor honoring ritual on Saturdays",
      timeline: "6-12 months with consistent practice"
    },
    {
      category: "relationship",
      severity: 6,
      manifestation: "Repeating partner dynamics, abandonment fears",
      rootCause: "Past-life separation trauma",
      ritual: "Self-love mirror work daily for 40 days",
      timeline: "3-6 months"
    },
    {
      category: "career",
      severity: 5,
      manifestation: "Stuck in unfulfilling roles, authority conflicts",
      rootCause: "Saturn-Sun tension, father wound",
      ritual: "Offer water to Sun every morning",
      timeline: "12-18 months"
    }
  ],
  
  impacts: [
    {
      dateRange: "Next 7 days",
      type: "opportunity",
      actions: ["Initiate difficult conversations", "Make bold decisions"],
      avoid: ["Procrastination", "Seeking approval"],
      energy: 8
    },
    {
      dateRange: "Days 8-14",
      type: "caution",
      actions: ["Review and reflect", "Rest and integrate"],
      avoid: ["Major decisions", "New projects"],
      energy: 4
    },
    {
      dateRange: "Days 15-30",
      type: "opportunity",
      actions: ["Financial planning", "Commit to long-term goals"],
      avoid: ["Impulsive spending", "Short-term thinking"],
      energy: 7
    }
  ],
  
  radar: {
    dimensions: [
      { area: "Career", score: 6 },
      { area: "Wealth", score: 4 },
      { area: "Relationships", score: 5 },
      { area: "Health", score: 7 },
      { area: "Creativity", score: 8 },
      { area: "Spirituality", score: 6 }
    ],
    leaks: [
      {
        area: "Wealth",
        severity: 6,
        symptom: "Money flows out as fast as it comes in",
        rootCause: "Venus-Rahu conjunction in 2nd house",
        plugRitual: "Donate to women's causes every Friday"
      },
      {
        area: "Relationships",
        severity: 5,
        symptom: "Difficulty maintaining boundaries",
        rootCause: "Moon in 7th house, people-pleasing pattern",
        plugRitual: "Practice saying 'no' 3 times this week"
      }
    ]
  },
  
  bond: {
    toxic: [
      {
        who: "Colleague or family member draining your energy",
        why: "Karmic completion pattern - lesson already learned",
        action: "Compassionate distance, reduce contact by 50%"
      }
    ],
    boundaries: [
      {
        where: "Work-life separation",
        how: "Set hard stop time at 6pm, no exceptions",
        script: "I'm not available after 6pm. Let's schedule this for tomorrow."
      }
    ],
    soulContracts: [
      {
        with: "Primary romantic partner or close friend",
        purpose: "Mirror work - they reflect your shadow",
        honor: "Stay present even when uncomfortable, don't run"
      }
    ]
  }
};

class KarmaCache {
  private cache = new Map<string, { data: any; timestamp: number }>();
  private TTL = 24 * 60 * 60 * 1000;

  getCacheKey(tool: KarmaTool, input: KarmaInput): string {
    return `${tool}:${input.birthDate}:${input.birthTime}:${input.birthPlace}`;
  }

  get(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;
    
    const age = Date.now() - cached.timestamp;
    if (age > this.TTL) {
      this.cache.delete(key);
      return null;
    }
    
    return cached.data;
  }

  set(key: string, data: any): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
  }

  clear(): void {
    this.cache.clear();
  }
}

const cache = new KarmaCache();

async function callOpenRouter(systemPrompt: string, userPrompt: string): Promise<string> {
  const config = getOpenRouterConfig();
  
  if (!config.enabled) {
    throw new Error('OpenRouter not configured');
  }

  const response = await fetch(`${config.apiBase}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${config.apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': process.env.NEXT_PUBLIC_APP_URL || 'https://astrokalki.com',
      'X-Title': 'AstroKalki'
    },
    body: JSON.stringify({
      model: 'google/gemini-2.0-flash-exp:free',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: 0.7,
      max_tokens: 2000
    })
  });

  if (!response.ok) {
    throw new Error(`OpenRouter API error: ${response.statusText}`);
  }

  const json = await response.json();
  return json.choices[0]?.message?.content || '';
}

async function callGemini(systemPrompt: string, userPrompt: string): Promise<string> {
  const config = getGeminiConfig();
  
  if (!config.enabled) {
    throw new Error('Gemini not configured');
  }

  const combinedPrompt = `${systemPrompt}\n\n${userPrompt}`;
  
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${config.apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: combinedPrompt }]
        }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2000
        }
      })
    }
  );

  if (!response.ok) {
    throw new Error(`Gemini API error: ${response.statusText}`);
  }

  const json = await response.json();
  return json.candidates[0]?.content?.parts[0]?.text || '';
}

export async function runKarmaTool(
  tool: KarmaTool,
  input: KarmaInput
): Promise<KarmaOutput> {
  try {
    const cacheKey = cache.getCacheKey(tool, input);
    const cached = cache.get(cacheKey);
    
    if (cached) {
      return {
        success: true,
        data: cached,
        cached: true
      };
    }

    const systemPrompt = SYSTEM_PROMPTS[tool];
    const userPrompt = USER_PROMPT_TEMPLATES[tool](input);

    let responseText: string;
    
    try {
      responseText = await callOpenRouter(systemPrompt, userPrompt);
    } catch (error) {
      console.warn('OpenRouter failed, trying Gemini:', error);
      try {
        responseText = await callGemini(systemPrompt, userPrompt);
      } catch (geminiError) {
        console.warn('Gemini failed, using demo mode:', geminiError);
        return {
          success: true,
          data: DEMO_RESPONSES[tool],
          demoMode: true
        };
      }
    }

    let parsedData: any;
    try {
      parsedData = JSON.parse(responseText);
    } catch {
      parsedData = { rawResponse: responseText };
    }

    cache.set(cacheKey, parsedData);

    return {
      success: true,
      data: parsedData
    };

  } catch (error) {
    console.error(`Karma tool ${tool} error:`, error);
    
    return {
      success: true,
      data: DEMO_RESPONSES[tool],
      demoMode: true
    };
  }
}

export function clearKarmaCache(): void {
  cache.clear();
}
