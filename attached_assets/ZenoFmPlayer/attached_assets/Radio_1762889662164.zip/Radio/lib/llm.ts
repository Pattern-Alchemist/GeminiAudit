import { getGeminiConfig, getOpenRouterConfig } from './env';

type ToolIdentifier = 'karma-ledger' | 'dharma-path' | 'destiny-window';

type GenerationRequest = {
  tool: ToolIdentifier;
  prompt: string;
};

type GenerationResult = {
  provider: 'openrouter' | 'gemini' | 'mock';
  content: string;
};

const toolIntros: Record<ToolIdentifier, string> = {
  'karma-ledger': 'Karma Ledger Report',
  'dharma-path': 'Dharma Path Audio',
  'destiny-window': '7-Day Destiny Window'
};

export async function generateToolResponse(request: GenerationRequest): Promise<GenerationResult> {
  const openrouter = getOpenRouterConfig();
  if (openrouter.enabled) {
    return {
      provider: 'openrouter',
      content: `[[openrouter:${toolIntros[request.tool]}]] ${request.prompt}`
    };
  }

  const gemini = getGeminiConfig();
  if (gemini.enabled) {
    return {
      provider: 'gemini',
      content: `[[gemini:${toolIntros[request.tool]}]] ${request.prompt}`
    };
  }

  return {
    provider: 'mock',
    content: `[[mock:${toolIntros[request.tool]}]] ${request.prompt}`
  };
}
