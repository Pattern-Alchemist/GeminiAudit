import { getResendConfig } from './env';

type NotificationPayload = {
  to: string;
  subject: string;
  body: string;
};

export async function sendReceiptNotification(payload: NotificationPayload) {
  const resend = getResendConfig();

  if (!resend.enabled) {
    return { delivered: false, reason: 'Integration disabled: Resend missing key' };
  }

  // Placeholder until hooked up to Resend SDK
  console.info('Email dispatch', { ...payload, provider: 'Resend' });
  return { delivered: true };
}
