import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: ['class'],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './lib/**/*.{ts,tsx}'
  ],
  theme: {
    extend: {
      colors: {
        cosmic: {
          background: '#05080E',
          surface: '#0F141F',
          muted: '#1B2333',
          aurora: '#1BA689',
          copper: '#B87333',
          copperBright: '#DA8A3C',
          text: '#E6E0D4',
          secondary: '#6EC2B0'
        }
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui']
      },
      boxShadow: {
        glow: '0 0 40px rgba(218, 138, 60, 0.25)'
      }
    }
  },
  plugins: []
};

export default config;
