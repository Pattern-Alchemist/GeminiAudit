#!/usr/bin/env node
import { writeFileSync } from 'node:fs';

const openapi = {
  openapi: '3.1.0',
  info: {
    title: 'AstroKalki API',
    version: '1.0.0'
  },
  paths: {
    '/api/paypal/create-order': {
      post: {
        summary: 'Create a PayPal order'
      }
    },
    '/api/paypal/webhook': {
      post: {
        summary: 'PayPal webhook listener'
      }
    },
    '/api/upi/create-intent': {
      post: {
        summary: 'Generate UPI intent URI'
      }
    },
    '/api/upi/verify': {
      post: {
        summary: 'Mark UPI payment for manual verification'
      }
    }
  }
};

writeFileSync('public/openapi.json', JSON.stringify(openapi, null, 2));
console.log('OpenAPI spec written to public/openapi.json');
