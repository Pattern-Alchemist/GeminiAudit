# AstroKalki - Karma Engine Platform

## Overview

AstroKalki is a karma-first spiritual technology platform built on Next.js 14 with App Router. The core of the platform is the **Karma Engine** - a system of 5 interconnected tools (DNA, Debts, Impacts, Radar, Bond) powered by AI (OpenRouter/Gemini) that decode users' karmic patterns and provide actionable dharmic guidance.

The platform features:
- **Karma Engine**: 5 core tools with AI-powered analysis and graceful demo mode
- **QuickScan**: 90-second onboarding that captures birth data and generates initial karmic insights
- **Dashboard**: Daily Pulse (Do/Avoid/Connect), Truth slider, streak tracking, and tool access
- **Feature Flags**: Toggle optional features (Courses, Shop, Tarot, Horoscope) via admin panel
- **Secure Authentication**: Supabase Auth with role-based access (user/admin)
- **Events Tracking**: Analytics for tool usage, pulse completion, and user actions
- **Payment Integration**: UPI and PayPal for consultations and premium features

Built with Next.js 14, TypeScript, Supabase, Tailwind CSS, and a cosmic neon dark theme.

## Recent Changes (November 11, 2025)

### Karma Engine Foundation - Phase 1 Complete

**Database Schema** (Migration Ready):
- Created `supabase/migrations/0002_karma_engine.sql` with:
  - `karma_reads`: Stores DNA, Debts, Impacts, Radar, Bond readings
  - `events`: Analytics tracking for tool usage, pulse completion, actions
  - `feature_flags`: Global toggles for optional features
  - `copy_tables`: Deterministic Vedic content (nakshatras, Saturn, nodes, etc.)
  - `reports`: PDF exports with secure share tokens
  - `courses`, `products`, `orders`: Feature-flagged commerce tables
  - `client_profiles`: Intake form data with birth information
  - Updated `profiles`: Added role, streak_days, birth data fields
  - All tables secured with RLS policies (users see their data, admins see all)
  - Streak automation via trigger on pulse completion events

**Authentication & Security** (`lib/auth.ts`):
- Session-based authentication helpers
- `getAuthenticatedUser()`: Safe user retrieval
- `requireAuth()`: Protected route guard
- `requireAdmin()`: Admin-only access control
- All API routes secured (no client-controlled user IDs)

**Karma Engine Library** (`lib/karma-engine.ts`):
- AI integration (OpenRouter primary, Gemini fallback)
- 24-hour caching to save API credits
- Graceful demo mode when API keys missing
- All 5 core tools + QuickScan prompts
- Demo responses for offline/keyless operation

**Feature Flags System**:
- API: `/api/feature-flags` (GET public, PATCH admin-only)
- Hook: `lib/hooks/use-feature-flags.ts` with SWR
- Admin UI: `components/admin/FeatureFlagsPanel.tsx`
- Default flags: courses, shop, tarot, horoscope (all disabled)

**Karma Tools Built**:
- **QuickScan** (`/karma/scan`): 90-second onboarding, generates initial karmic insights
- **DNA** (`/karma/dna`): Full karmic blueprint with gifts, challenges, soul purpose
- Both tools save to `karma_reads` and log analytics events

**Dashboard** (`/dashboard`):
- Daily Pulse: Do/Avoid/Connect actions
- Truth Slider: 1-10 alignment tracking
- Streak Badge: Days of consistent practice
- Tool Cards: Quick access to all 5 Karma tools
- Real-time data from Supabase (streak, recent reads)

**Events Tracking** (`/api/events`):
- POST: Requires auth, logs user events
- GET: Requires auth, users see their events, admins see all
- Event types: tool_used, pulse_completed, truth_logged, etc.

**Migration Guide**: Created `MIGRATION_GUIDE.md` with instructions for applying the schema to Supabase.

### What Still Needs Building
- [ ] 3 remaining Karma tools (Debts, Impacts, Radar, Bond)
- [ ] Mobile/desktop navigation (bottom nav + left rail)
- [ ] Ledger page (events list with filters)
- [ ] Zeno FM radio integration
- [ ] PDF export system
- [ ] Consultations flow (with Cal.com)
- [ ] Billing page
- [ ] Admin dashboard
- [ ] Updated home page
- [ ] Status page (integration health)

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Routing**: Next.js 14 with App Router using file-based routing organized by locale (`[locale]` dynamic segments). The application uses TypeScript throughout with strict mode enabled.

**Internationalization**: Implemented via `next-intl` with support for English (`en`) and Hindi (`hi`) locales. Translation messages are stored in TypeScript modules under `i18n/messages/`. The middleware handles locale detection and routing with `localePrefix: 'as-needed'` strategy.

**Component Design**: Uses a combination of Radix UI primitives (@radix-ui/react-*) for accessible base components (Dialog, Dropdown Menu, Popover, Label, Separator) and custom-built components. The design system follows a "cosmic copper" aesthetic with dark mode only, featuring gradient rings, glassmorphic panels, and shadow-glow effects.

**State Management**: Client-side state uses React hooks. Data fetching leverages SWR for client components and Next.js server components for initial data loading. No global state management library is employed.

**Styling**: Tailwind CSS with custom theme extensions defining the cosmic color palette (background, surface, muted, aurora, copper variants, text colors). Global styles provide utility classes for `.card-surface`, `.glass-panel`, `.gradient-ring`, and `.badge`.

### Backend Architecture

**API Routes**: RESTful endpoints organized under `/app/api/` with the following structure:
- **Payments**: PayPal order creation and webhooks, UPI intent generation and verification
- **Tools**: LLM-powered tool generation endpoints
- **Consultations**: Scheduling integration with Cal.com and LiveKit token generation for video calls

**Server Actions**: The architecture relies primarily on API routes rather than Next.js server actions. Server components fetch data directly where needed.

**Integration Pattern**: All third-party integrations use a graceful degradation pattern. Missing environment variables disable features without crashing, surfacing warnings via `IntegrationBanner` component. The `lib/env.ts` module centralizes environment validation.

**Payment Processing**: 
- PayPal: Create order → redirect to approval → webhook captures payment status
- UPI: Generate deep link URI → user completes payment externally → manual verification endpoint logs attempt

**Content Generation**: Supports multiple LLM providers (OpenRouter, Gemini) with automatic fallback to mock responses when APIs are unavailable. Tool generation produces karma reports, dharma audio, and destiny windows.

### Data Storage

**Primary Database**: Supabase Postgres with Row Level Security (RLS) for multi-tenant organization support. The schema includes tables for users, organizations, media, tools, payments, and audit logs (referenced in migration file `supabase/migrations/0001_init.sql`).

**Authentication**: Supabase Auth with session persistence and auto-refresh tokens. Uses `@supabase/auth-helpers-nextjs` for Next.js integration.

**Client Access**: Browser-side operations use `supabaseClient` with anon key. Server-side operations use `getServerSupabase()` with service role key or user access tokens.

**Data Flow**: Client components fetch via SWR → Supabase client. Server components and API routes use service role client for privileged operations.

### External Dependencies

**Authentication & Database**:
- Supabase: Postgres database, authentication, and Row Level Security
  - Required: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`

**Payment Providers**:
- PayPal: Premium tool purchases and consultation payments
  - Required: `PAYPAL_URL` (approval redirect endpoint)
- UPI: India-based payment deep links
  - Required: `UPI_ID` (recipient identifier)

**AI & Content Generation**:
- OpenRouter: Primary LLM provider for karma reports and dharma content
  - Required: `OPENROUTER_API_KEY`, `OPENROUTER_API_BASE`
- Google Gemini: Fallback LLM provider
  - Required: `GEMINI_API_KEY`

**Scheduling & Calendar**:
- Cal.com: Consultation booking integration
  - Required: `CAL_COM_API_KEY`, `CAL_COM_LINK`

**Real-time Communication**:
- LiveKit: Video consultation infrastructure
  - Required: `LIVEKIT_URL`, `LIVEKIT_API_KEY`, `LIVEKIT_API_SECRET`, `NEXT_PUBLIC_LIVEKIT_URL`

**Email Notifications**:
- Resend: Receipt and confirmation emails
  - Required: `RESEND_API_KEY`

**Testing Infrastructure**:
- Vitest: Unit and accessibility testing with jsdom environment
- Playwright: End-to-end browser testing
- axe-core: Accessibility violation detection
- @testing-library/react: Component testing utilities

**Build & Development**:
- Next.js runs on port 5000 binding to 0.0.0.0
- OpenAPI schema generation via custom Node script (`scripts/generate-openapi.js`)
- Separate test configurations for unit (`vitest.config.ts`) and a11y (`vitest.a11y.config.ts`)