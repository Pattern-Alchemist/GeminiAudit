-- Karma Engine Schema Migration
-- Adds tables for DNA, Debts, Impacts, Radar, Bond + supporting infrastructure

-- Update profiles with Karma Engine fields
alter table profiles 
  add column if not exists role text default 'user' check (role in ('user', 'admin')),
  add column if not exists streak_days integer default 0,
  add column if not exists last_pulse_at timestamptz,
  add column if not exists birth_date date,
  add column if not exists birth_time time,
  add column if not exists birth_place text,
  add column if not exists timezone text default 'UTC';

-- Feature flags (global toggles)
create table if not exists feature_flags (
  key text primary key,
  enabled boolean default false,
  meta jsonb default '{}'::jsonb,
  updated_at timestamptz default now()
);

-- Insert default feature flags
insert into feature_flags (key, enabled, meta) values
  ('courses', false, '{"label": "Celestial Codex Courses"}'::jsonb),
  ('shop', false, '{"label": "Crystal & Stone Shop"}'::jsonb),
  ('tarot', false, '{"label": "Tarot Readings"}'::jsonb),
  ('horoscope', false, '{"label": "Daily Horoscope"}'::jsonb)
on conflict (key) do nothing;

-- Karma reads (DNA, Debts, Impacts, Radar, Bond)
create table if not exists karma_reads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  tool_slug text not null check (tool_slug in ('dna', 'debts', 'impacts', 'radar', 'bond', 'scan')),
  input_data jsonb not null default '{}'::jsonb,
  output_data jsonb not null default '{}'::jsonb,
  anchors jsonb default '[]'::jsonb, -- Key insights/patterns
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  expires_at timestamptz -- For cached/temp reads
);

create index karma_reads_user_tool_idx on karma_reads(user_id, tool_slug, created_at desc);
create index karma_reads_created_idx on karma_reads(created_at desc);

-- Events (truth logs, actions, money logs, relationship logs)
create table if not exists events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  event_type text not null check (event_type in (
    'truth_logged', 'action_completed', 'money_logged', 'relationship_logged',
    'tool_used', 'pulse_completed', 'consultation_booked', 'upgrade_clicked',
    'pdf_exported', 'share_clicked'
  )),
  data jsonb not null default '{}'::jsonb,
  created_at timestamptz default now()
);

create index events_user_type_idx on events(user_id, event_type, created_at desc);
create index events_created_idx on events(created_at desc);

-- Copy tables (deterministic vedic content)
create table if not exists copy_tables (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in (
    'nakshatra', 'saturn', 'rahu', 'ketu', 'debts', 'house_leaks', 'remedies'
  )),
  key text not null,
  content jsonb not null,
  tags text[] default '{}',
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  unique(category, key)
);

create index copy_tables_category_idx on copy_tables(category);

-- Reports (PDF exports)
create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  report_type text not null check (report_type in (
    'dna', 'debts', 'impacts', 'radar', 'bond', 'weekly_summary', 'consultation'
  )),
  title text not null,
  data jsonb not null default '{}'::jsonb,
  pdf_url text, -- Supabase Storage URL
  share_token text unique,
  created_at timestamptz default now()
);

create index reports_user_type_idx on reports(user_id, report_type, created_at desc);
create index reports_share_token_idx on reports(share_token) where share_token is not null;

-- Courses (for when feature flag is enabled)
create table if not exists courses (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  subtitle text,
  description text,
  cover_url text,
  price_inr integer not null default 0,
  level text check (level in ('beginner', 'intermediate', 'advanced')),
  tags text[] default '{}',
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists course_lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid references courses(id) on delete cascade,
  order_idx integer not null,
  title text not null,
  audio_url text,
  pdf_url text,
  duration_sec integer default 0,
  created_at timestamptz default now(),
  unique(course_id, order_idx)
);

create table if not exists enrollments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  course_id uuid references courses(id) on delete cascade,
  status text default 'active' check (status in ('active', 'refunded', 'pending')),
  progress jsonb default '{}'::jsonb,
  enrolled_at timestamptz default now(),
  unique(user_id, course_id)
);

-- Products (for shop feature flag)
create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  type text not null check (type in ('course', 'physical', 'digital')),
  slug text unique not null,
  title text not null,
  subtitle text,
  description text,
  price_inr integer not null default 0,
  media jsonb default '[]'::jsonb, -- Array of image URLs
  metadata jsonb default '{}'::jsonb, -- Properties, chakra, origin, etc.
  is_active boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists inventory (
  product_id uuid primary key references products(id) on delete cascade,
  sku text unique not null,
  quantity integer default 0 check (quantity >= 0),
  updated_at timestamptz default now()
);

-- Orders (physical products, courses, consultations)
create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  total_inr integer not null,
  currency text default 'INR',
  status text default 'pending' check (status in ('pending', 'paid', 'failed', 'refunded')),
  provider text check (provider in ('upi', 'paypal', 'manual')),
  provider_ref text,
  items jsonb not null default '[]'::jsonb,
  shipping_address jsonb,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index orders_user_status_idx on orders(user_id, status, created_at desc);

-- Client profiles (intake forms)
create table if not exists client_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  full_name text not null,
  email text not null,
  birth_date date not null,
  birth_time time not null,
  birth_place text not null,
  timezone text default 'Asia/Kolkata',
  goals text,
  notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Enable RLS on new tables
alter table feature_flags enable row level security;
alter table karma_reads enable row level security;
alter table events enable row level security;
alter table copy_tables enable row level security;
alter table reports enable row level security;
alter table courses enable row level security;
alter table course_lessons enable row level security;
alter table enrollments enable row level security;
alter table products enable row level security;
alter table inventory enable row level security;
alter table orders enable row level security;
alter table client_profiles enable row level security;

-- RLS Policies

-- Feature flags: anyone can read, only admins can update
create policy "Anyone can view feature flags" on feature_flags
  for select using (true);

create policy "Admins can update feature flags" on feature_flags
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Karma reads: users see their own, admins see all
create policy "Users view their karma reads" on karma_reads
  for select using (user_id = auth.uid() or exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
  ));

create policy "Users create their karma reads" on karma_reads
  for insert with check (user_id = auth.uid());

-- Events: users see their own, admins see all
create policy "Users view their events" on events
  for select using (user_id = auth.uid() or exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
  ));

create policy "Users create their events" on events
  for insert with check (user_id = auth.uid());

-- Copy tables: read-only for all authenticated users, admins can modify
create policy "Authenticated users view copy tables" on copy_tables
  for select using (auth.role() = 'authenticated');

create policy "Admins manage copy tables" on copy_tables
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Reports: users see their own, admins see all
-- Note: Shared reports require separate access via public RPC function
create policy "Users view their reports" on reports
  for select using (
    user_id = auth.uid() 
    or exists (
      select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
    )
  );

create policy "Users create their reports" on reports
  for insert with check (user_id = auth.uid());

create policy "Admins manage reports" on reports
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Courses: public read when active
create policy "Anyone can view active courses" on courses
  for select using (is_active = true);

create policy "Admins manage courses" on courses
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Course lessons: enrolled users + admins
create policy "Enrolled users view lessons" on course_lessons
  for select using (
    exists (
      select 1 from enrollments
      where enrollments.course_id = course_lessons.course_id
        and enrollments.user_id = auth.uid()
        and enrollments.status = 'active'
    )
    or exists (
      select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
    )
  );

create policy "Admins manage course lessons" on course_lessons
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Enrollments: users see their own
create policy "Users view their enrollments" on enrollments
  for select using (user_id = auth.uid() or exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
  ));

create policy "Users create enrollments" on enrollments
  for insert with check (user_id = auth.uid());

-- Products: public read when active
create policy "Anyone can view active products" on products
  for select using (is_active = true);

create policy "Admins manage products" on products
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Inventory: public read
create policy "Anyone can view inventory" on inventory
  for select using (true);

create policy "Admins manage inventory" on inventory
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Orders: users see their own, admins see and manage all
create policy "Users view their orders" on orders
  for select using (user_id = auth.uid() or exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
  ));

create policy "Users create orders" on orders
  for insert with check (user_id = auth.uid());

create policy "Admins manage orders" on orders
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Client profiles: users manage their own, admins see all
create policy "Users view their client profiles" on client_profiles
  for select using (user_id = auth.uid() or exists (
    select 1 from profiles where profiles.id = auth.uid() and profiles.role = 'admin'
  ));

create policy "Users manage their client profiles" on client_profiles
  for all using (user_id = auth.uid());

create policy "Admins manage client profiles" on client_profiles
  for all using (
    exists (
      select 1 from profiles
      where profiles.id = auth.uid()
        and profiles.role = 'admin'
    )
  );

-- Functions for common operations

-- Secure shared report access by token (bypasses RLS)
create or replace function get_shared_report(token text)
returns table (
  id uuid,
  user_id uuid,
  report_type text,
  title text,
  data jsonb,
  pdf_url text,
  created_at timestamptz
) as $$
begin
  return query
  select 
    r.id,
    r.user_id,
    r.report_type,
    r.title,
    r.data,
    r.pdf_url,
    r.created_at
  from reports r
  where r.share_token = token;
end;
$$ language plpgsql security definer stable
set search_path = public;

-- Update streak when pulse is logged
create or replace function update_user_streak()
returns trigger as $$
begin
  if NEW.event_type = 'pulse_completed' then
    update profiles
    set 
      last_pulse_at = NEW.created_at,
      streak_days = case
        when last_pulse_at is null then 1
        when last_pulse_at::date = (NEW.created_at - interval '1 day')::date then streak_days + 1
        when last_pulse_at::date = NEW.created_at::date then streak_days
        else 1
      end
    where id = NEW.user_id;
  end if;
  return NEW;
end;
$$ language plpgsql;

create trigger update_streak_on_pulse
  after insert on events
  for each row
  when (NEW.event_type = 'pulse_completed')
  execute function update_user_streak();
