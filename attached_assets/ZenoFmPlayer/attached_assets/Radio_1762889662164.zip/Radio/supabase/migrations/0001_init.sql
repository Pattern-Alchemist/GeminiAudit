-- Organizations and memberships
create table if not exists organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text unique not null,
  created_at timestamptz default now()
);

create table if not exists profiles (
  id uuid primary key references auth.users on delete cascade,
  full_name text,
  locale text default 'en',
  created_at timestamptz default now()
);

create table if not exists memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  role text not null default 'member',
  created_at timestamptz default now(),
  unique (organization_id, user_id)
);

-- Episodes
create table if not exists episodes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  title text not null,
  description text,
  duration interval,
  tags text[] default '{}',
  audio_url text,
  created_at timestamptz default now()
);

-- Tools
create table if not exists tools (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  name text not null,
  description text,
  price_cents integer,
  currency text default 'USD',
  format text,
  is_free boolean default false,
  created_at timestamptz default now()
);

-- Consultations
create table if not exists consultations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  name text not null,
  description text,
  duration_minutes integer,
  price_cents integer,
  currency text default 'USD',
  jitsi_room text,
  created_at timestamptz default now()
);

-- Purchases & payments
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  provider text not null,
  status text not null,
  reference text not null,
  amount_cents integer,
  currency text,
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);

-- Access tokens for digital goods
create table if not exists access_tokens (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  user_id uuid references profiles(id) on delete cascade,
  resource_type text not null,
  resource_id uuid,
  status text default 'active',
  issued_at timestamptz default now(),
  expires_at timestamptz
);

-- Audit log
create table if not exists audit_log (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references organizations(id) on delete cascade,
  actor_id uuid references profiles(id) on delete cascade,
  action text not null,
  payload jsonb,
  created_at timestamptz default now()
);

alter table audit_log enable row level security;
alter table organizations enable row level security;
alter table memberships enable row level security;
alter table episodes enable row level security;
alter table tools enable row level security;
alter table consultations enable row level security;
alter table payments enable row level security;
alter table access_tokens enable row level security;

create policy "Members can view their org data" on organizations
  for select using (exists (
    select 1 from memberships m
    where m.organization_id = organizations.id
      and m.user_id = auth.uid()
  ));

create policy "Members manage episodes" on episodes
  for all using (exists (
    select 1 from memberships m
    where m.organization_id = episodes.organization_id
      and m.user_id = auth.uid()
  ));

create policy "Members manage tools" on tools
  for all using (exists (
    select 1 from memberships m
    where m.organization_id = tools.organization_id
      and m.user_id = auth.uid()
  ));

create policy "Members manage consultations" on consultations
  for all using (exists (
    select 1 from memberships m
    where m.organization_id = consultations.organization_id
      and m.user_id = auth.uid()
  ));

create policy "Members view payments" on payments
  for select using (exists (
    select 1 from memberships m
    where m.organization_id = payments.organization_id
      and m.user_id = auth.uid()
  ));

create policy "Members insert payments" on payments
  for insert with check (exists (
    select 1 from memberships m
    where m.organization_id = payments.organization_id
      and m.user_id = auth.uid()
  ));

create policy "Members manage access tokens" on access_tokens
  for all using (exists (
    select 1 from memberships m
    where m.organization_id = access_tokens.organization_id
      and m.user_id = auth.uid()
  ));

create policy "Members view audit log" on audit_log
  for select using (exists (
    select 1 from memberships m
    where m.organization_id = audit_log.organization_id
      and m.user_id = auth.uid()
  ));
