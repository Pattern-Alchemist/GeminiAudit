import { test } from '@playwright/test';

test.skip(true, 'Browser-based smoke tests run in deployment environments.');

test('placeholder', async ({ page }) => {
  await page.goto('about:blank');
});
