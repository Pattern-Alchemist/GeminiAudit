import { afterEach, describe, expect, it } from 'vitest';
import { getIntegrationWarnings } from '@/lib/env';

const originalEnv = { ...process.env };

afterEach(() => {
  process.env = { ...originalEnv };
});

describe('getIntegrationWarnings', () => {
  it('flags OpenRouter when keys missing', () => {
    delete process.env.OPENROUTER_API_KEY;
    delete process.env.OPENROUTER_API_BASE;

    const warnings = getIntegrationWarnings();
    expect(warnings.some((warning) => warning.service === 'OpenRouter')).toBe(true);
  });
});
