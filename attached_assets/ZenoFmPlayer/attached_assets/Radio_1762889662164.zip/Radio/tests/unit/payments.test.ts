import { describe, expect, it } from 'vitest';
import { buildUpiUri } from '@/lib/payments';

describe('buildUpiUri', () => {
  it('formats deep link with amount and purpose', () => {
    const uri = buildUpiUri({
      upiId: '9211271977@hdfcbank',
      amount: 1999.5,
      currency: 'INR',
      purpose: 'Karma Ledger'
    });

    expect(uri).toBe('upi://pay?pa=9211271977%40hdfcbank&pn=AstroKalki&am=1999.50&cu=INR&tn=Karma+Ledger');
  });
});
