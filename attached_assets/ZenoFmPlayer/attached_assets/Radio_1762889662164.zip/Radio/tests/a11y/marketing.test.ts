import axe from 'axe-core';
import { describe, expect, it } from 'vitest';

describe('marketing hero accessibility', () => {
  it('renders markup without critical axe violations', async () => {
    document.body.innerHTML = `
      <main>
        <section aria-labelledby="hero-heading">
          <h1 id="hero-heading">Decode Karma. Align Dharma.</h1>
          <p>Your deeds are your destiny interface.</p>
          <div role="group" aria-label="Primary calls to action">
            <a href="#" role="button">Start Free Karma Scan</a>
            <a href="#" role="button">Book Consultation</a>
          </div>
        </section>
      </main>
    `;

    const results = await axe.run(document.body, {
      rules: {
        'color-contrast': { enabled: false }
      }
    });

    expect(results.violations).toStrictEqual([]);
  });
});
