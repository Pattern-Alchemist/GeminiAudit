'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useTranslations } from 'next-intl';
import { AccentButton } from './AccentButton';
import { cn } from '@/lib/utils';

export function SiteHeader() {
  const pathname = usePathname();
  const t = useTranslations('navigation');
  const segments = pathname?.split('/') ?? [];
  const locale = segments[1] && segments[1].length === 2 ? segments[1] : 'en';

  const items = [
    { href: `/${locale}`, label: t('home') },
    { href: `/${locale}/app`, label: t('dashboard') },
    { href: `/${locale}/app/billing`, label: t('billing') },
    { href: `/${locale}/radio`, label: t('radio') },
    { href: `/${locale}/tools`, label: t('tools') },
    { href: `/${locale}/consultations`, label: t('consultations') },
    { href: `/${locale}/admin`, label: t('admin') },
    { href: `/${locale}/developer/docs`, label: t('docs') }
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-cosmic-muted/40 bg-cosmic-background/85 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link href={`/${locale}`} className="flex items-center gap-3 text-white">
          <span className="h-3 w-3 rounded-full bg-gradient-to-r from-cosmic-copper to-cosmic-copperBright" />
          <span className="text-lg font-semibold">AstroKalki</span>
        </Link>
        <nav className="hidden items-center gap-6 text-sm text-cosmic-text/70 md:flex">
          {items.map((item) => {
            const isActive = pathname?.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'transition hover:text-cosmic-copper',
                  isActive ? 'text-cosmic-copper' : undefined
                )}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
        <AccentButton className="hidden md:inline-flex" asChild>
          <Link href={`/${locale}/app`}>{t('dashboard')}</Link>
        </AccentButton>
      </div>
    </header>
  );
}
