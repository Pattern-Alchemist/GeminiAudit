import { LucideIcon } from 'lucide-react';
import { ReactNode } from 'react';
import { AccentButton } from './AccentButton';
import { cn } from '@/lib/utils';

interface ToolCardProps {
  name: string;
  description: string;
  cta: string;
  icon: LucideIcon;
  accent?: 'free' | 'paid';
  badge?: string;
  price?: string;
  footer?: ReactNode;
  onAction?: () => void;
  className?: string;
}

export function ToolCard({
  name,
  description,
  cta,
  icon: Icon,
  accent = 'free',
  badge,
  price,
  footer,
  onAction,
  className
}: ToolCardProps) {
  return (
    <div className={cn('card-surface flex h-full flex-col justify-between p-6', className)}>
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <div className="rounded-full bg-cosmic-muted/60 p-3 text-cosmic-copper">
            <Icon className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-white">{name}</h3>
            {badge ? <span className="badge text-cosmic-aurora/90">{badge}</span> : null}
          </div>
        </div>
        <p className="text-sm text-cosmic-text/70">{description}</p>
      </div>
      <div className="mt-6 space-y-4">
        {price ? <p className="text-lg font-semibold text-cosmic-copper">{price}</p> : null}
        <AccentButton variant={accent === 'free' ? 'solid' : 'outline'} onClick={onAction} className="w-full">
          {cta}
        </AccentButton>
        {footer}
      </div>
    </div>
  );
}
