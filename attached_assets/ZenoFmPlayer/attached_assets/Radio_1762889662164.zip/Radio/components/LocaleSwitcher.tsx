'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { locales } from '@/i18n/config';
import { cn } from '@/lib/utils';

export function LocaleSwitcher() {
  const pathname = usePathname();
  const segments = pathname?.split('/') ?? [];
  const currentLocale = segments[1] && segments[1].length === 2 ? segments[1] : 'en';
  const rest = segments.slice(2).join('/');

  return (
    <div className="inline-flex items-center gap-2 rounded-full border border-cosmic-muted/50 bg-cosmic-surface/60 px-3 py-2 text-xs uppercase tracking-[0.2em] text-cosmic-text/60">
      {locales.map((locale) => (
        <Link
          key={locale}
          href={`/${locale}${rest ? `/${rest}` : ''}`}
          className={cn(
            'rounded-full px-2 py-1 transition',
            currentLocale === locale
              ? 'bg-gradient-to-r from-cosmic-copper to-cosmic-copperBright text-black'
              : 'hover:text-cosmic-copper'
          )}
        >
          {locale}
        </Link>
      ))}
    </div>
  );
}
