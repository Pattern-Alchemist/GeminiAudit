'use client';

import { useFeatureFlags } from '@/lib/hooks/use-feature-flags';
import { useState } from 'react';

export function FeatureFlagsPanel() {
  const { flags, isLoading, toggleFlag } = useFeatureFlags();
  const [updating, setUpdating] = useState<string | null>(null);

  const handleToggle = async (key: string, currentValue: boolean) => {
    setUpdating(key);
    await toggleFlag(key, !currentValue);
    setUpdating(null);
  };

  if (isLoading) {
    return (
      <div className="animate-pulse space-y-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-16 bg-surface/50 rounded-lg" />
        ))}
      </div>
    );
  }

  const flagEntries = Object.entries(flags);

  if (flagEntries.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted">No feature flags configured</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="space-y-3">
        {flagEntries.map(([key, flag]: [string, any]) => (
          <div
            key={key}
            className="flex items-center justify-between p-4 bg-surface/30 border border-white/10 rounded-lg hover:bg-surface/50 transition-colors"
          >
            <div className="flex-1">
              <h3 className="font-medium text-text capitalize">
                {key.replace(/_/g, ' ')}
              </h3>
              {flag.meta?.label && (
                <p className="text-sm text-muted mt-1">{flag.meta.label}</p>
              )}
            </div>
            <button
              onClick={() => handleToggle(key, flag.enabled)}
              disabled={updating === key}
              className={`
                relative inline-flex h-6 w-11 items-center rounded-full transition-colors
                focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background
                ${flag.enabled ? 'bg-primary' : 'bg-muted/30'}
                ${updating === key ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              `}
            >
              <span
                className={`
                  inline-block h-4 w-4 transform rounded-full bg-white transition-transform
                  ${flag.enabled ? 'translate-x-6' : 'translate-x-1'}
                `}
              />
            </button>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-aurora/5 border border-aurora/20 rounded-lg">
        <p className="text-sm text-muted">
          <strong className="text-aurora">Note:</strong> Feature flags control
          the visibility of optional sections like Courses, Shop, Tarot, and
          Horoscope. Disabling a flag will hide the feature from all users.
        </p>
      </div>
    </div>
  );
}
