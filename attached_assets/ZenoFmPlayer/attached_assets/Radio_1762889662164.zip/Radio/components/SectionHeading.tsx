import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
  actions?: ReactNode;
  className?: string;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  actions,
  className
}: SectionHeadingProps) {
  return (
    <div className={cn('flex flex-col gap-4 md:flex-row md:items-end md:justify-between', className)}>
      <div>
        <span className="badge text-cosmic-aurora">{eyebrow}</span>
        <h2 className="mt-3 text-3xl font-semibold text-white md:text-4xl">{title}</h2>
        {description ? (
          <p className="mt-2 max-w-2xl text-base text-cosmic-text/70">{description}</p>
        ) : null}
      </div>
      {actions ? <div className="flex items-center gap-3">{actions}</div> : null}
    </div>
  );
}
