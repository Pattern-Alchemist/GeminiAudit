import { Slot } from '@radix-ui/react-slot';
import { ButtonHTMLAttributes } from 'react';
import { cn } from '@/lib/utils';

interface AccentButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'solid' | 'outline' | 'ghost';
  asChild?: boolean;
}

export function AccentButton({
  className,
  children,
  variant = 'solid',
  asChild,
  type,
  ...props
}: AccentButtonProps) {
  const base =
    'inline-flex items-center justify-center gap-2 rounded-full px-5 py-2 text-sm font-semibold transition focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cosmic-copper focus-visible:ring-offset-2 focus-visible:ring-offset-cosmic-background';

  const variants: Record<typeof variant, string> = {
    solid: 'bg-gradient-to-r from-cosmic-copper to-cosmic-copperBright text-black shadow-glow hover:from-cosmic-copperBright hover:to-cosmic-copper',
    outline:
      'border border-cosmic-copper/70 text-cosmic-copper hover:bg-cosmic-copper/10',
    ghost: 'text-cosmic-copper hover:text-cosmic-copperBright'
  } as const;

  const Component = asChild ? Slot : 'button';

  return (
    <Component
      className={cn(base, variants[variant], className)}
      {...(!asChild ? { type: type ?? 'button' } : {})}
      {...props}
    >
      {children}
    </Component>
  );
}
