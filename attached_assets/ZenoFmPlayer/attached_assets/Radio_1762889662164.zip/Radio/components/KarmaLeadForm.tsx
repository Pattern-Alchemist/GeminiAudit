'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { AccentButton } from './AccentButton';

export function KarmaLeadForm() {
  const t = useTranslations('forms');
  const [submitted, setSubmitted] = useState(false);

  return (
    <form
      className="space-y-3"
      onSubmit={(event) => {
        event.preventDefault();
        setSubmitted(true);
      }}
    >
      <input
        type="text"
        required
        placeholder={t('name')}
        className="w-full rounded-full border border-cosmic-muted/50 bg-cosmic-surface/60 px-4 py-3 text-sm text-white placeholder:text-cosmic-text/40 focus:border-cosmic-copper focus:outline-none"
      />
      <input
        type="email"
        required
        placeholder={t('email')}
        className="w-full rounded-full border border-cosmic-muted/50 bg-cosmic-surface/60 px-4 py-3 text-sm text-white placeholder:text-cosmic-text/40 focus:border-cosmic-copper focus:outline-none"
      />
      <AccentButton type="submit" className="w-full">
        {t('submit')}
      </AccentButton>
      {submitted ? (
        <p className="text-sm text-cosmic-aurora">{t('success')}</p>
      ) : (
        <p className="text-xs text-cosmic-text/50">
          By submitting you create a Supabase account and agree to receive karma insights.
        </p>
      )}
    </form>
  );
}
