import { clsx } from 'clsx';

type IntegrationConfig = {
  service: string;
  missing: string[];
};

export function IntegrationBanner({ warnings }: { warnings: IntegrationConfig[] }) {
  if (!warnings.length) {
    return null;
  }

  return (
    <div
      role="status"
      className={clsx(
        'mb-6 rounded-lg border border-aurora-highlight/40 bg-cosmic-surface/80 p-4 text-sm text-aurora-highlight',
        'shadow-[0_0_30px_rgba(0,255,200,0.15)] backdrop-blur'
      )}
    >
      <p className="font-medium uppercase tracking-wide">Integration status</p>
      <ul className="mt-2 space-y-1 text-xs text-cosmic-muted">
        {warnings.map((warning) => (
          <li key={warning.service}>
            Integration disabled: {warning.service} missing key
            {warning.missing.length > 1 ? 's' : ''} ({warning.missing.join(', ')}).
          </li>
        ))}
      </ul>
    </div>
  );
}
