import { AccentButton } from './AccentButton';
import { cn } from '@/lib/utils';

interface ConsultationPlanCardProps {
  name: string;
  price: string;
  description: string;
  highlight?: boolean;
  ctaText?: string;
}

export function ConsultationPlanCard({
  name,
  price,
  description,
  highlight,
  ctaText = 'Reserve Session'
}: ConsultationPlanCardProps) {
  return (
    <div
      className={cn(
        'card-surface flex h-full flex-col justify-between p-6 transition',
        highlight ? 'border-cosmic-copper shadow-glow' : 'border-transparent'
      )}
    >
      <div className="space-y-4">
        <h3 className="text-2xl font-semibold text-white">{name}</h3>
        <p className="text-lg font-semibold text-cosmic-copper">{price}</p>
        <p className="text-sm text-cosmic-text/70">{description}</p>
      </div>
      <AccentButton className="mt-6 w-full">{ctaText}</AccentButton>
    </div>
  );
}
