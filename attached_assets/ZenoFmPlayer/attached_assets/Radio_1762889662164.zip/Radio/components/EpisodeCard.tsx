import { PlayCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface EpisodeCardProps {
  title: string;
  description: string;
  duration: string;
  tags: string[];
  className?: string;
}

export function EpisodeCard({ title, description, duration, tags, className }: EpisodeCardProps) {
  return (
    <div className={cn('card-surface p-6 transition hover:shadow-glow', className)}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
          <p className="mt-2 text-sm text-cosmic-text/70">{description}</p>
        </div>
        <div className="rounded-full bg-cosmic-muted/60 p-2 text-cosmic-copper">
          <PlayCircle className="h-6 w-6" />
        </div>
      </div>
      <div className="mt-4 flex flex-wrap items-center gap-3 text-xs text-cosmic-text/60">
        <span className="rounded-full border border-cosmic-aurora/30 px-3 py-1 text-cosmic-aurora">{duration}</span>
        {tags.map((tag) => (
          <span
            key={tag}
            className="rounded-full border border-cosmic-muted px-3 py-1 text-cosmic-text/60"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  );
}
