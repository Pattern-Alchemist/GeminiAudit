export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-cosmic-muted/40 bg-cosmic-background/80">
      <div className="mx-auto flex max-w-7xl flex-col gap-6 px-6 py-10 md:flex-row md:items-center md:justify-between">
        <div>
          <p className="text-sm text-cosmic-text/60">© {new Date().getFullYear()} AstroKalki. Karma-first spiritual tech.</p>
        </div>
        <div className="flex items-center gap-4 text-sm text-cosmic-text/60">
          <a href="mailto:hello@astrokalki.com" className="hover:text-cosmic-copper">
            Support
          </a>
          <a href="#" className="hover:text-cosmic-copper">
            Privacy
          </a>
          <a href="#" className="hover:text-cosmic-copper">
            Terms
          </a>
        </div>
      </div>
    </footer>
  );
}
