'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

interface PulseData {
  do: string[];
  avoid: string[];
  connect: string;
}

export default function DashboardPage() {
  const [pulse, setPulse] = useState<PulseData | null>(null);
  const [truth, setTruth] = useState(5);
  const [streak, setStreak] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboard();
  }, []);

  const loadDashboard = async () => {
    try {
      const response = await fetch('/api/dashboard');
      const data = await response.json();
      
      if (data.pulse) setPulse(data.pulse);
      if (data.streak !== undefined) setStreak(data.streak);
    } catch (error) {
      console.error('Dashboard load error:', error);
      setPulse({
        do: ['Complete one unfinished task', 'Practice gratitude meditation'],
        avoid: ['Starting new projects', 'Major decisions'],
        connect: 'Reach out to an old friend or mentor'
      });
      setStreak(0);
    } finally {
      setLoading(false);
    }
  };

  const logPulse = async () => {
    try {
      await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event_type: 'pulse_completed',
          data: { truth, timestamp: new Date().toISOString() }
        })
      });
      
      setStreak(prev => prev + 1);
      alert('Pulse logged! Streak updated.');
    } catch (error) {
      console.error('Log pulse error:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-text mb-2">Dashboard</h1>
          <p className="text-muted">Your karmic command center</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          <div className="card-surface p-6 rounded-xl">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold text-text">
                Today's Pulse
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted">Streak:</span>
                <div className="px-3 py-1 bg-primary/20 border border-primary/40 rounded-full">
                  <span className="text-primary font-bold">{streak} days</span>
                </div>
              </div>
            </div>

            {pulse && (
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-copper-400 mb-2 uppercase tracking-wide">
                    Do
                  </h3>
                  <ul className="space-y-2">
                    {pulse.do.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-text">
                        <span className="text-primary mt-1">✓</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-aurora mb-2 uppercase tracking-wide">
                    Avoid
                  </h3>
                  <ul className="space-y-2">
                    {pulse.avoid.map((item, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-text">
                        <span className="text-aurora mt-1">✗</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-primary mb-2 uppercase tracking-wide">
                    Connect
                  </h3>
                  <p className="text-text">{pulse.connect}</p>
                </div>
              </div>
            )}
          </div>

          <div className="card-surface p-6 rounded-xl">
            <h2 className="text-2xl font-semibold text-text mb-4">
              Truth Slider
            </h2>
            <p className="text-muted mb-6">
              How aligned were you today? (1 = off track, 10 = dharmic flow)
            </p>

            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="1"
                  max="10"
                  value={truth}
                  onChange={(e) => setTruth(parseInt(e.target.value))}
                  className="flex-1 h-2 bg-surface rounded-lg appearance-none cursor-pointer
                    [&::-webkit-slider-thumb]:appearance-none
                    [&::-webkit-slider-thumb]:w-5
                    [&::-webkit-slider-thumb]:h-5
                    [&::-webkit-slider-thumb]:rounded-full
                    [&::-webkit-slider-thumb]:bg-primary
                    [&::-webkit-slider-thumb]:cursor-pointer"
                />
                <div className="w-12 text-center">
                  <span className="text-2xl font-bold text-primary">{truth}</span>
                </div>
              </div>

              <button
                onClick={logPulse}
                className="w-full px-6 py-3 bg-gradient-to-r from-primary to-aurora text-background font-semibold rounded-lg hover:opacity-90 transition-opacity"
              >
                Log Today's Truth
              </button>
            </div>

            <div className="mt-6 text-sm text-muted">
              <p>Logging builds your streak and trains the Karma Engine to give you better insights.</p>
            </div>
          </div>
        </div>

        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <Link
            href="/karma/dna"
            className="card-surface p-6 rounded-xl hover:scale-105 transition-transform cursor-pointer"
          >
            <div className="text-primary text-3xl mb-3">🧬</div>
            <h3 className="text-lg font-semibold text-text mb-2">DNA</h3>
            <p className="text-sm text-muted">Decode your karmic blueprint</p>
          </Link>

          <Link
            href="/karma/debts"
            className="card-surface p-6 rounded-xl hover:scale-105 transition-transform cursor-pointer"
          >
            <div className="text-copper-400 text-3xl mb-3">⚖️</div>
            <h3 className="text-lg font-semibold text-text mb-2">Debts</h3>
            <p className="text-sm text-muted">Clear your karmic ledger</p>
          </Link>

          <Link
            href="/karma/impacts"
            className="card-surface p-6 rounded-xl hover:scale-105 transition-transform cursor-pointer"
          >
            <div className="text-aurora text-3xl mb-3">⏰</div>
            <h3 className="text-lg font-semibold text-text mb-2">Impacts</h3>
            <p className="text-sm text-muted">Map your 90-day windows</p>
          </Link>

          <Link
            href="/karma/radar"
            className="card-surface p-6 rounded-xl hover:scale-105 transition-transform cursor-pointer"
          >
            <div className="text-primary text-3xl mb-3">📡</div>
            <h3 className="text-lg font-semibold text-text mb-2">Radar</h3>
            <p className="text-sm text-muted">Scan for energy leaks</p>
          </Link>

          <Link
            href="/karma/bond"
            className="card-surface p-6 rounded-xl hover:scale-105 transition-transform cursor-pointer"
          >
            <div className="text-copper-400 text-3xl mb-3">🔗</div>
            <h3 className="text-lg font-semibold text-text mb-2">Bond</h3>
            <p className="text-sm text-muted">Set healthy boundaries</p>
          </Link>

          <Link
            href="/karma/scan"
            className="card-surface p-6 rounded-xl hover:scale-105 transition-transform cursor-pointer border border-primary/30"
          >
            <div className="text-primary text-3xl mb-3">⚡</div>
            <h3 className="text-lg font-semibold text-text mb-2">QuickScan</h3>
            <p className="text-sm text-muted">90-second karma check</p>
          </Link>
        </div>
      </div>
    </div>
  );
}
