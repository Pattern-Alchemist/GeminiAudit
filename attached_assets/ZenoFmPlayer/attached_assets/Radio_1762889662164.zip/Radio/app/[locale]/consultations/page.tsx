import { ConsultationPlanCard } from '@/components/ConsultationPlanCard';
import { SectionHeading } from '@/components/SectionHeading';
import { AccentButton } from '@/components/AccentButton';
import { useMessages, useTranslations } from 'next-intl';
import { CalendarDays, Video } from 'lucide-react';

export default function ConsultationsPage() {
  const t = useTranslations('consultations');
  const messages = useMessages();
  const plans = (messages.consultations?.plans ?? []) as Array<{ name: string; price: string; description: string }>;

  return (
    <div className="space-y-16">
      <section className="rounded-3xl border border-cosmic-copper/30 bg-cosmic-surface/50 p-10 shadow-glow">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="max-w-2xl space-y-4">
            <span className="badge text-cosmic-aurora">Live guidance</span>
            <h1 className="text-4xl font-semibold text-white">Book your dharma consultation</h1>
            <p className="text-sm text-cosmic-text/60">
              Each consultation concludes with a Jitsi link and token stored in your dashboard. Sacred conversation meets modern
              delivery.
            </p>
          </div>
          <div className="flex items-center gap-4 text-sm text-cosmic-text/60">
            <CalendarDays className="h-6 w-6 text-cosmic-copper" />
            <span>Choose a window • Receive rituals • Align action</span>
          </div>
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Plans" title="Consultation tiers" />
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {plans.map((plan, index) => (
            <ConsultationPlanCard
              key={plan.name}
              name={plan.name}
              price={plan.price}
              description={plan.description}
              highlight={index === 1}
              ctaText={t('cta')}
            />
          ))}
        </div>
      </section>

      <section className="card-surface p-10">
        <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="space-y-2">
            <h2 className="text-2xl font-semibold text-white">After payment</h2>
            <p className="text-sm text-cosmic-text/60">
              Our team verifies PayPal capture or UPI proof. Once approved, a Jitsi meeting link is generated and delivered with
              your access token.
            </p>
          </div>
          <AccentButton variant="outline" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            Join from browser
          </AccentButton>
        </div>
      </section>
    </div>
  );
}
