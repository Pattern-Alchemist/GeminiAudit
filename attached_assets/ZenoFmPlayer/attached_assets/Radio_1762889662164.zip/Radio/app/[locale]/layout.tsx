import { NextIntlClientProvider } from 'next-intl';
import { notFound } from 'next/navigation';
import { ReactNode } from 'react';
import { Locale, locales } from '@/i18n/config';
import { SiteHeader } from '@/components/SiteHeader';
import { SiteFooter } from '@/components/SiteFooter';
import { LocaleSwitcher } from '@/components/LocaleSwitcher';
import { IntegrationBanner } from '@/components/IntegrationBanner';
import { getIntegrationWarnings } from '@/lib/env';

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({
  params,
  children
}: {
  params: { locale: Locale };
  children: ReactNode;
}) {
  if (!locales.includes(params.locale)) {
    notFound();
  }

  const messages = (await import(`@/i18n/messages/${params.locale}.ts`)).default;

  const warnings = getIntegrationWarnings();

  return (
    <NextIntlClientProvider locale={params.locale} messages={messages}>
      <div className="min-h-screen bg-cosmic-background text-cosmic-text">
        <div className="gradient-ring pointer-events-none fixed inset-x-1/4 top-[-10rem] h-64 rounded-full blur-3xl" />
        <SiteHeader />
        <main className="mx-auto w-full max-w-7xl px-6 pb-24 pt-16">
          <div className="mb-10 flex justify-end">
            <LocaleSwitcher />
          </div>
          <IntegrationBanner warnings={warnings} />
          {children}
        </main>
        <SiteFooter />
      </div>
    </NextIntlClientProvider>
  );
}
