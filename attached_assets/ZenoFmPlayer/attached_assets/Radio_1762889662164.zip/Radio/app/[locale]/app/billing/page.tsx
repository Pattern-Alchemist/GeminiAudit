import { AccentButton } from '@/components/AccentButton';
import { SectionHeading } from '@/components/SectionHeading';
import { getPaymentConfiguration } from '@/lib/env';
import { resolveActivePaymentChannels } from '@/lib/payments';
import { getTranslations } from 'next-intl/server';

export default async function BillingPage({ params }: { params: { locale: string } }) {
  const t = await getTranslations({ locale: params.locale, namespace: 'billing' });
  const payments = getPaymentConfiguration();
  const channels = resolveActivePaymentChannels();

  return (
    <div className="space-y-12">
      <SectionHeading eyebrow={t('eyebrow')} title={t('title')} />
      <p className="max-w-2xl text-sm text-cosmic-text/60">{t('intro')}</p>

      <div className="grid gap-6 md:grid-cols-2">
        <div className="card-surface border border-cosmic-muted/40 p-6">
          <h2 className="text-xl font-semibold text-white">PayPal</h2>
          <p className="mt-2 text-sm text-cosmic-text/60">{t('paypalDescription')}</p>
          <AccentButton
            className="mt-4"
            asChild
            disabled={!channels.paypal}
            variant={channels.paypal ? 'default' : 'ghost'}
          >
            <a href={payments.paypalUrl ?? '#'} aria-disabled={!channels.paypal}>
              {channels.paypal ? t('paypalCta') : t('paypalDisabled')}
            </a>
          </AccentButton>
        </div>
        <div className="card-surface border border-cosmic-muted/40 p-6">
          <h2 className="text-xl font-semibold text-white">UPI</h2>
          <p className="mt-2 text-sm text-cosmic-text/60">{t('upiDescription')}</p>
          <div className="mt-4 rounded-lg border border-dashed border-cosmic-muted/50 bg-cosmic-surface/60 p-4 text-sm">
            {channels.upi ? (
              <>
                <p className="font-mono text-lg text-cosmic-copper">{payments.upiId}</p>
                <p className="mt-1 text-xs text-cosmic-text/60">{t('upiHint')}</p>
              </>
            ) : (
              <p>{t('upiDisabled')}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
