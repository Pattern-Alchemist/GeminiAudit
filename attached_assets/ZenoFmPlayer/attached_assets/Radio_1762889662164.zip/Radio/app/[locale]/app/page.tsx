import { AccentButton } from '@/components/AccentButton';
import { EpisodeCard } from '@/components/EpisodeCard';
import { SectionHeading } from '@/components/SectionHeading';
import { ToolCard } from '@/components/ToolCard';
import { buildUpiUri } from '@/lib/payments';
import { getPaymentConfiguration } from '@/lib/env';
import { getTranslations } from 'next-intl/server';
import { CalendarDays, Layers, FileText, FileAudio, RefreshCw } from 'lucide-react';

const ledgerUpsell = {
  name: 'Karma Ledger Report',
  description: 'Transform your free scan into a full 90-day ledger with rituals, mantras, and accountability.',
  amount: 79
};

export default async function DashboardPage({ params }: { params: { locale: string } }) {
  const t = await getTranslations({ locale: params.locale, namespace: 'dashboard' });
  const payments = getPaymentConfiguration();
  const upiUri = payments.upiId
    ? buildUpiUri({ amount: ledgerUpsell.amount, currency: 'INR', upiId: payments.upiId, purpose: ledgerUpsell.name })
    : null;

  return (
    <div className="space-y-16">
      <section className="grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="card-surface p-8">
          <h1 className="text-3xl font-semibold text-white">{t('title')}</h1>
          <p className="mt-3 text-sm text-cosmic-text/60">
            Your deeds are your destiny interface. Track every token, consultation, and aurora broadcast here.
          </p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {[{ label: t('freeTools'), icon: Layers }, { label: t('purchasedTools'), icon: FileText }, { label: t('consultations'), icon: CalendarDays }].map(
              (item) => (
                <div key={item.label} className="card-surface border border-cosmic-muted/40 p-4">
                  <item.icon className="h-5 w-5 text-cosmic-copper" />
                  <p className="mt-4 text-sm text-cosmic-text/60">{item.label}</p>
                </div>
              )
            )}
          </div>
        </div>
        <div className="card-surface space-y-4 p-6">
          <h2 className="text-xl font-semibold text-white">{t('upsellTitle')}</h2>
          <p className="text-sm text-cosmic-text/60">{t('upsellDescription')}</p>
          <AccentButton className="w-full">{t('ledgerCta')}</AccentButton>
          <AccentButton variant="outline" className="w-full" asChild>
            <a href={upiUri ?? '#'} aria-disabled={!upiUri}>
              Pay via UPI
            </a>
          </AccentButton>
          <AccentButton variant="ghost" className="w-full">
            {t('consultCta')}
          </AccentButton>
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Tools" title={t('freeTools')} />
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            { name: 'Karma Pulse', description: 'Recent scan ready • Last updated 2 hours ago', icon: RefreshCw },
            { name: 'Compatibility Snapshot', description: 'Unlock deeper ledger for relationships', icon: FileText },
            { name: '7-Day Destiny Window', description: 'Daily rituals scheduled • Next refresh tomorrow', icon: CalendarDays }
          ].map((tool) => (
            <ToolCard
              key={tool.name}
              name={tool.name}
              description={tool.description}
              cta="View report"
              icon={tool.icon}
              accent="free"
            />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Deep Tools" title={t('purchasedTools')} />
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            { name: 'Karma Ledger Report', description: 'Activated • Next update in 30 days', icon: FileText },
            { name: 'Dharma Path Reading', description: 'Audio portal unlocked', icon: FileAudio },
            { name: 'Karma Detox Routine', description: 'PDF + audio rituals in progress', icon: RefreshCw }
          ].map((tool) => (
            <ToolCard
              key={tool.name}
              name={tool.name}
              description={tool.description}
              cta="Download"
              icon={tool.icon}
              accent="paid"
            />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Radio" title={t('episodes')} />
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            {
              title: 'Ledger Sync Breathwork',
              description: 'Use aurora breathing to reinforce your karmic commitments.',
              duration: '21 min',
              tags: ['breath', 'ledger']
            },
            {
              title: 'Sankalpa Journals',
              description: 'Write dharma-aligned intentions with cosmic copper focus.',
              duration: '18 min',
              tags: ['journaling']
            },
            {
              title: 'UPI Gratitude Flow',
              description: 'Transform digital payments into sacred exchanges.',
              duration: '16 min',
              tags: ['payments', 'ritual']
            }
          ].map((episode) => (
            <EpisodeCard key={episode.title} {...episode} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Finance" title={t('receipts')} />
        <div className="mt-6 overflow-hidden rounded-2xl border border-cosmic-muted/40">
          <table className="min-w-full text-left text-sm text-cosmic-text/70">
            <thead className="bg-cosmic-muted/40 text-xs uppercase tracking-[0.2em] text-cosmic-text/50">
              <tr>
                <th className="px-6 py-3">Reference</th>
                <th className="px-6 py-3">Type</th>
                <th className="px-6 py-3">Status</th>
                <th className="px-6 py-3">Amount</th>
              </tr>
            </thead>
            <tbody>
              {[{ ref: 'PAYPAL-3291', type: 'PayPal', status: 'Paid', amount: '$129' }, { ref: 'UPI-8723', type: 'UPI', status: 'Pending', amount: '₹6,499' }].map(
                (payment) => (
                  <tr key={payment.ref} className="border-t border-cosmic-muted/30">
                    <td className="px-6 py-4 text-white">{payment.ref}</td>
                    <td className="px-6 py-4">{payment.type}</td>
                    <td className="px-6 py-4">
                      <span className="badge text-cosmic-aurora">{payment.status}</span>
                    </td>
                    <td className="px-6 py-4 text-cosmic-copper">{payment.amount}</td>
                  </tr>
                )
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
