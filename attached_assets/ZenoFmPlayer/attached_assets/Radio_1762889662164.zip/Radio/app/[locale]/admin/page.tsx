'use client';

import { useMemo, useState } from 'react';
import { useTranslations } from 'next-intl';
import { ColumnDef, flexRender, getCoreRowModel, useReactTable } from '@tanstack/react-table';
import { AccentButton } from '@/components/AccentButton';
import { SectionHeading } from '@/components/SectionHeading';
import { cn } from '@/lib/utils';

interface PaymentRow {
  reference: string;
  method: 'PayPal' | 'UPI';
  status: 'pending' | 'paid';
  amount: string;
}

const paymentData: PaymentRow[] = [
  { reference: 'PAYPAL-5523', method: 'PayPal', status: 'paid', amount: '$129' },
  { reference: 'UPI-9834', method: 'UPI', status: 'pending', amount: '₹6,499' }
];

export default function AdminPage() {
  const t = useTranslations('admin');
  const [filter, setFilter] = useState<'all' | 'pending' | 'paid'>('all');

  const columns = useMemo<ColumnDef<PaymentRow>[]>(
    () => [
      { accessorKey: 'reference', header: 'Reference' },
      { accessorKey: 'method', header: 'Method' },
      {
        accessorKey: 'status',
        header: 'Status',
        cell: (info) => (
          <span
            className={cn(
              'badge',
              info.getValue<string>() === 'pending'
                ? 'text-cosmic-copper'
                : 'text-cosmic-aurora'
            )}
          >
            {info.getValue<string>().toUpperCase()}
          </span>
        )
      },
      { accessorKey: 'amount', header: 'Amount' }
    ],
    []
  );

  const table = useReactTable({
    data: paymentData.filter((row) => (filter === 'all' ? true : row.status === filter)),
    columns,
    getCoreRowModel: getCoreRowModel()
  });

  return (
    <div className="space-y-16">
      <section className="card-surface p-8">
        <h1 className="text-3xl font-semibold text-white">{t('title')}</h1>
        <p className="mt-3 max-w-2xl text-sm text-cosmic-text/60">{t('subtitle')}</p>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            { title: 'Episodes', value: '24', action: 'Add episode' },
            { title: 'Tools', value: '6', action: 'Add tool' },
            { title: 'Consultations', value: '12', action: 'Add consult' }
          ].map((stat) => (
            <div key={stat.title} className="card-surface border border-cosmic-muted/40 p-6">
              <p className="text-sm text-cosmic-text/50">{stat.title}</p>
              <p className="mt-2 text-2xl font-semibold text-white">{stat.value}</p>
              <AccentButton variant="outline" className="mt-4">
                {stat.action}
              </AccentButton>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Payments" title="UPI & PayPal" />
        <div className="mb-4 flex items-center gap-3 text-xs text-cosmic-text/50">
          <button
            className={cn(
              'rounded-full border border-cosmic-muted/40 px-3 py-1',
              filter === 'all' ? 'border-cosmic-copper text-cosmic-copper' : ''
            )}
            onClick={() => setFilter('all')}
          >
            All
          </button>
          <button
            className={cn(
              'rounded-full border border-cosmic-muted/40 px-3 py-1',
              filter === 'pending' ? 'border-cosmic-copper text-cosmic-copper' : ''
            )}
            onClick={() => setFilter('pending')}
          >
            Pending
          </button>
          <button
            className={cn(
              'rounded-full border border-cosmic-muted/40 px-3 py-1',
              filter === 'paid' ? 'border-cosmic-copper text-cosmic-copper' : ''
            )}
            onClick={() => setFilter('paid')}
          >
            Paid
          </button>
        </div>
        <div className="overflow-hidden rounded-2xl border border-cosmic-muted/40">
          <table className="min-w-full text-left text-sm text-cosmic-text/70">
            <thead className="bg-cosmic-muted/40 text-xs uppercase tracking-[0.2em] text-cosmic-text/50">
              {table.getHeaderGroups().map((headerGroup) => (
                <tr key={headerGroup.id}>
                  {headerGroup.headers.map((header) => (
                    <th key={header.id} className="px-6 py-3">
                      {header.isPlaceholder
                        ? null
                        : flexRender(header.column.columnDef.header, header.getContext())}
                    </th>
                  ))}
                </tr>
              ))}
            </thead>
            <tbody>
              {table.getRowModel().rows.map((row) => (
                <tr key={row.id} className="border-t border-cosmic-muted/30">
                  {row.getVisibleCells().map((cell) => (
                    <td key={cell.id} className="px-6 py-4">
                      {flexRender(cell.column.columnDef.cell, cell.getContext())}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section className="card-surface p-10">
        <h2 className="text-2xl font-semibold text-white">UPI verification</h2>
        <p className="mt-2 text-sm text-cosmic-text/60">
          Mark a payment as paid when the token has been issued. Pending UPI scans appear here for manual verification. Issue a
          consultation token to release the Jitsi link.
        </p>
        <div className="mt-6 flex flex-wrap gap-3">
          <AccentButton>{t('approve')}</AccentButton>
          <AccentButton variant="outline">{t('markPaid')}</AccentButton>
          <AccentButton variant="ghost">{t('reject')}</AccentButton>
        </div>
      </section>
    </div>
  );
}
