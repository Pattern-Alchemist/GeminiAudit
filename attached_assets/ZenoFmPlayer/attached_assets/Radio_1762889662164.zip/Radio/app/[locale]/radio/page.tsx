import { EpisodeCard } from '@/components/EpisodeCard';
import { SectionHeading } from '@/components/SectionHeading';
import { useTranslations } from 'next-intl';

const radioEpisodes = [
  {
    title: 'Karma Compass FM 001',
    description: 'Ground your energy with aurora breathing and dharma journaling prompts.',
    duration: '36 min',
    tags: ['breathwork', 'journaling']
  },
  {
    title: 'Ledger Sync 002',
    description: 'Align your weekly karma ledger with cosmic copper rituals.',
    duration: '42 min',
    tags: ['ledger', 'rituals']
  },
  {
    title: 'Consultation Prep 003',
    description: 'Prepare for your Dharma Alignment consultation with a guided meditation.',
    duration: '29 min',
    tags: ['consult', 'meditation']
  }
];

export default function RadioPage() {
  const t = useTranslations('marketing');

  return (
    <div className="space-y-16">
      <section className="glass-panel relative overflow-hidden rounded-3xl p-10">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(184,115,51,0.25),transparent)]" />
        <div className="relative flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
          <div className="max-w-xl space-y-4">
            <span className="badge text-cosmic-aurora">Radio</span>
            <h1 className="text-4xl font-semibold text-white">Aurora Radio Stream</h1>
            <p className="text-sm text-cosmic-text/70">
              Wide, glassmorphic player engineered for focused listening. Tune into karmic broadcasts that keep your dharma in
              orbit.
            </p>
          </div>
          <div className="relative w-full max-w-md rounded-3xl border border-cosmic-copper/40 bg-cosmic-background/80 p-6 text-white shadow-glow">
            <div className="mb-4 flex items-center justify-between text-xs uppercase tracking-[0.3em] text-cosmic-text/40">
              <span>Now Playing</span>
              <span>Live</span>
            </div>
            <h2 className="text-xl font-semibold">Karma Compass FM 001</h2>
            <p className="mt-2 text-sm text-cosmic-text/60">Breath + Journal Ritual</p>
            <div className="mt-6 h-2 w-full rounded-full bg-cosmic-muted">
              <div className="h-full w-2/3 rounded-full bg-gradient-to-r from-cosmic-copper to-cosmic-copperBright" />
            </div>
            <div className="mt-4 flex items-center justify-between text-xs text-cosmic-text/50">
              <span>12:44</span>
              <span>36:00</span>
            </div>
          </div>
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Episodes" title={t('episodesTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {radioEpisodes.map((episode) => (
            <EpisodeCard key={episode.title} {...episode} />
          ))}
        </div>
      </section>
    </div>
  );
}
