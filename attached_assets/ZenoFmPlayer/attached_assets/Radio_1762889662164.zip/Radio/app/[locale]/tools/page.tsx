import { ToolCard } from '@/components/ToolCard';
import { SectionHeading } from '@/components/SectionHeading';
import { KarmaLeadForm } from '@/components/KarmaLeadForm';
import { useMessages, useTranslations } from 'next-intl';
import { Layers, FileText, FileAudio, Infinity } from 'lucide-react';

export default function ToolsPage() {
  const t = useTranslations();
  const messages = useMessages();
  const freeTools = (messages.freeTools?.tools ?? []) as Array<{ name: string; description: string }>;
  const paidTools = (messages.paidTools?.tools ?? []) as Array<{
    name: string;
    description: string;
    price: string;
    format: string;
  }>;

  return (
    <div className="space-y-16">
      <section className="rounded-3xl border border-cosmic-muted/50 bg-cosmic-surface/40 p-10">
        <div className="grid gap-10 md:grid-cols-[2fr_1fr]">
          <div className="space-y-6">
            <span className="badge text-cosmic-aurora">Lead magnets</span>
            <h1 className="text-4xl font-semibold text-white">{t('marketing.freeToolsTitle')}</h1>
            <p className="text-sm text-cosmic-text/60">{t('freeTools.lead')}</p>
            <div className="grid gap-6 md:grid-cols-3">
              {freeTools.map((tool) => (
                <ToolCard
                  key={tool.name}
                  name={tool.name}
                  description={tool.description}
                  cta={t('marketing.primaryCta')}
                  icon={Layers}
                  accent="free"
                  badge="Free"
                />
              ))}
            </div>
          </div>
          <div className="card-surface p-6">
            <KarmaLeadForm />
          </div>
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Premium" title={t('marketing.paidToolsTitle')} />
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {paidTools.map((tool) => (
            <ToolCard
              key={tool.name}
              name={tool.name}
              description={`${tool.description} • ${tool.format}`}
              cta="Checkout"
              icon={tool.format.includes('Audio') ? FileAudio : FileText}
              accent="paid"
              price={tool.price}
              footer={<p className="text-xs text-cosmic-text/60">PayPal + UPI options available.</p>}
            />
          ))}
        </div>
      </section>

      <section className="card-surface p-10 text-center">
        <Infinity className="mx-auto h-10 w-10 text-cosmic-copper" />
        <h2 className="mt-4 text-3xl font-semibold text-white">Stack tools for karmic momentum</h2>
        <p className="mt-2 text-sm text-cosmic-text/60">
          Combine the Karma Ledger PDF with Dharma Path audio guidance to maintain a full-spectrum transformation loop.
        </p>
      </section>
    </div>
  );
}
