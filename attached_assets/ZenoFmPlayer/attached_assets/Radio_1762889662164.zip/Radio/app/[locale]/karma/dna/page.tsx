'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function DNAPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    birthDate: '',
    birthTime: '',
    birthPlace: '',
    timezone: 'Asia/Kolkata'
  });
  const [result, setResult] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/karma/dna', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (data.success) {
        setResult(data);
        setStep(2);
      } else {
        alert('Error: ' + (data.error || 'Failed to generate DNA read'));
      }
    } catch (error) {
      console.error('DNA error:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (step === 2 && result) {
    const dna = result.data;
    
    return (
      <div className="min-h-screen bg-background px-4 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-5xl font-bold text-text mb-3">
              Your Karmic DNA
            </h1>
            <p className="text-muted text-lg">
              The blueprint of your soul's journey
            </p>
            {result.demoMode && (
              <div className="mt-4 inline-block px-4 py-2 bg-aurora/10 border border-aurora/30 rounded-lg text-sm text-aurora">
                Demo Mode - Configure API keys for personalized readings
              </div>
            )}
          </div>

          <div className="space-y-8">
            <div className="card-surface p-8 rounded-2xl border-2 border-primary/30">
              <div className="flex items-start gap-4">
                <div className="text-5xl">🧬</div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-primary mb-3">
                    Core Pattern
                  </h2>
                  <p className="text-text text-lg leading-relaxed">
                    {dna?.corePattern || 'Processing your karmic signature...'}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="card-surface p-6 rounded-xl">
                <div className="flex items-start gap-3">
                  <div className="text-3xl">✨</div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-copper-400 mb-3">
                      Gifts
                    </h3>
                    <ul className="space-y-2">
                      {(dna?.gifts || []).map((gift: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2 text-text">
                          <span className="text-primary mt-1">✦</span>
                          <span>{gift}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              <div className="card-surface p-6 rounded-xl">
                <div className="flex items-start gap-3">
                  <div className="text-3xl">⚔️</div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-aurora mb-3">
                      Challenges
                    </h3>
                    <ul className="space-y-2">
                      {(dna?.challenges || []).map((challenge: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-2 text-text">
                          <span className="text-aurora mt-1">⦿</span>
                          <span>{challenge}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div className="card-surface p-8 rounded-2xl border border-white/10">
              <div className="flex items-start gap-4">
                <div className="text-4xl">🎯</div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-text mb-3">
                    Soul Purpose
                  </h2>
                  <p className="text-text text-lg leading-relaxed mb-6">
                    {dna?.soulPurpose || 'Revealing your dharmic path...'}
                  </p>
                  <div className="bg-primary/10 border border-primary/30 rounded-lg p-4">
                    <p className="text-sm font-medium text-primary mb-2 uppercase tracking-wide">
                      Immediate Action
                    </p>
                    <p className="text-text">
                      {dna?.immediateAction || 'Calculating next step...'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-10 flex flex-col sm:flex-row gap-4">
            <Link
              href="/karma/debts"
              className="flex-1 px-6 py-4 bg-gradient-to-r from-primary to-aurora text-background font-bold text-center rounded-lg hover:opacity-90 transition-opacity"
            >
              Clear Your Karmic Debts →
            </Link>
            <Link
              href="/dashboard"
              className="flex-1 px-6 py-4 border border-copper-400 text-copper-400 font-bold text-center rounded-lg hover:bg-copper-400/10 transition-colors"
            >
              Back to Dashboard
            </Link>
            <button
              onClick={() => {
                setStep(1);
                setResult(null);
              }}
              className="px-6 py-4 border border-white/20 text-muted font-semibold rounded-lg hover:bg-white/5 transition-colors"
            >
              New Reading
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-12">
      <div className="max-w-lg mx-auto">
        <div className="text-center mb-8">
          <div className="text-6xl mb-4">🧬</div>
          <h1 className="text-4xl font-bold text-text mb-2">
            Karmic DNA Reading
          </h1>
          <p className="text-muted text-lg">
            Decode your soul's blueprint and life purpose
          </p>
        </div>

        <div className="card-surface p-6 rounded-xl mb-6">
          <h2 className="text-lg font-semibold text-text mb-3">
            What You'll Discover
          </h2>
          <ul className="space-y-2 text-sm text-muted">
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">✦</span>
              <span>Your core karmic pattern and signature</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">✦</span>
              <span>Natural gifts from past-life karma</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">✦</span>
              <span>Challenges and lessons to master</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">✦</span>
              <span>Your soul's dharmic purpose</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-primary mt-1">✦</span>
              <span>One immediate action to take</span>
            </li>
          </ul>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Birth Date
            </label>
            <input
              type="date"
              required
              value={formData.birthDate}
              onChange={(e) => handleChange('birthDate', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Birth Time
            </label>
            <input
              type="time"
              required
              value={formData.birthTime}
              onChange={(e) => handleChange('birthTime', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Birth Place
            </label>
            <input
              type="text"
              required
              placeholder="e.g., Mumbai, India"
              value={formData.birthPlace}
              onChange={(e) => handleChange('birthPlace', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Timezone
            </label>
            <select
              value={formData.timezone}
              onChange={(e) => handleChange('timezone', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="Asia/Kolkata">Asia/Kolkata (IST)</option>
              <option value="America/New_York">America/New_York (EST)</option>
              <option value="America/Los_Angeles">America/Los_Angeles (PST)</option>
              <option value="Europe/London">Europe/London (GMT)</option>
              <option value="UTC">UTC</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full px-6 py-4 bg-gradient-to-r from-primary to-aurora text-background font-bold text-lg rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Decoding Your DNA...' : 'Reveal My Karmic DNA'}
          </button>

          <p className="text-center text-sm text-muted">
            Deep analysis • 100% private • Powered by Vedic wisdom
          </p>
        </form>
      </div>
    </div>
  );
}
