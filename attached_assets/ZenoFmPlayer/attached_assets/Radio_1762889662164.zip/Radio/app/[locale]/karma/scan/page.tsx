'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function QuickScanPage() {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    birthDate: '',
    birthTime: '',
    birthPlace: '',
    timezone: 'Asia/Kolkata'
  });
  const [result, setResult] = useState<any>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await fetch('/api/karma/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (data.success) {
        setResult(data);
        setStep(2);
      } else {
        alert('Error: ' + (data.error || 'Failed to generate scan'));
      }
    } catch (error) {
      console.error('Scan error:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (step === 2 && result) {
    return (
      <div className="min-h-screen bg-background px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-text mb-2">
              Your Karmic Quick Scan
            </h1>
            {result.demoMode && (
              <div className="inline-block px-4 py-2 bg-aurora/10 border border-aurora/30 rounded-lg text-sm text-aurora">
                Demo Mode - Configure API keys for personalized readings
              </div>
            )}
          </div>

          <div className="space-y-6">
            <div className="card-surface p-6 rounded-xl">
              <h2 className="text-xl font-semibold text-primary mb-3">
                Core Pattern
              </h2>
              <p className="text-text text-lg">
                {result.data?.pattern || 'Processing...'}
              </p>
            </div>

            <div className="card-surface p-6 rounded-xl">
              <h2 className="text-xl font-semibold text-copper-400 mb-3">
                Immediate Action
              </h2>
              <p className="text-text">
                {result.data?.action || 'Processing...'}
              </p>
            </div>

            <div className="card-surface p-6 rounded-xl">
              <h2 className="text-xl font-semibold text-muted mb-3">
                Avoid This Week
              </h2>
              <p className="text-text">
                {result.data?.avoid || 'Processing...'}
              </p>
            </div>

            {result.data?.energy && (
              <div className="card-surface p-6 rounded-xl">
                <h2 className="text-xl font-semibold text-aurora mb-3">
                  Energy Level
                </h2>
                <div className="flex items-center gap-3">
                  <div className="flex-1 h-3 bg-surface rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-primary to-aurora"
                      style={{ width: `${(result.data.energy / 10) * 100}%` }}
                    />
                  </div>
                  <span className="text-text font-bold">
                    {result.data.energy}/10
                  </span>
                </div>
              </div>
            )}
          </div>

          <div className="mt-8 flex gap-4">
            <button
              onClick={() => router.push('/karma/dna')}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-primary to-aurora text-background font-semibold rounded-lg hover:opacity-90 transition-opacity"
            >
              Get Full DNA Read
            </button>
            <button
              onClick={() => router.push('/dashboard')}
              className="flex-1 px-6 py-3 border border-copper-400 text-copper-400 font-semibold rounded-lg hover:bg-copper-400/10 transition-colors"
            >
              Go to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background px-4 py-12">
      <div className="max-w-lg mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-text mb-2">
            Quick Karmic Scan
          </h1>
          <p className="text-muted">
            90 seconds to decode your current karma
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Birth Date
            </label>
            <input
              type="date"
              required
              value={formData.birthDate}
              onChange={(e) => handleChange('birthDate', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Birth Time
            </label>
            <input
              type="time"
              required
              value={formData.birthTime}
              onChange={(e) => handleChange('birthTime', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Birth Place
            </label>
            <input
              type="text"
              required
              placeholder="e.g., Mumbai, India"
              value={formData.birthPlace}
              onChange={(e) => handleChange('birthPlace', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text placeholder:text-muted focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text mb-2">
              Timezone
            </label>
            <select
              value={formData.timezone}
              onChange={(e) => handleChange('timezone', e.target.value)}
              className="w-full px-4 py-3 bg-surface border border-white/10 rounded-lg text-text focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="Asia/Kolkata">Asia/Kolkata (IST)</option>
              <option value="America/New_York">America/New_York (EST)</option>
              <option value="America/Los_Angeles">America/Los_Angeles (PST)</option>
              <option value="Europe/London">Europe/London (GMT)</option>
              <option value="UTC">UTC</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full px-6 py-4 bg-gradient-to-r from-primary to-aurora text-background font-bold text-lg rounded-lg hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Scanning Karma...' : 'Start QuickScan'}
          </button>

          <p className="text-center text-sm text-muted">
            Takes 90 seconds • 100% private • No credit card
          </p>
        </form>
      </div>
    </div>
  );
}
