import { NextResponse } from 'next/server';

export async function GET(_: Request, { params }: { params: { locale: string } }) {
  const openapi = {
    openapi: '3.1.0',
    info: {
      title: 'AstroKalki API',
      version: '1.0.0',
      description: 'Programmatic access to AstroKalki karma tools, consultations, and payments.'
    },
    servers: [{ url: `https://api.astrokalki.com/${params.locale}` }],
    paths: {
      '/api/paypal/create-order': {
        post: {
          summary: 'Create a PayPal order',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    referenceId: { type: 'string' },
                    amount: { type: 'number' },
                    currency: { type: 'string' }
                  },
                  required: ['referenceId', 'amount', 'currency']
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'Order created',
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      id: { type: 'string' },
                      approvalUrl: { type: 'string' }
                    }
                  }
                }
              }
            }
          }
        }
      },
      '/api/upi/create-intent': {
        post: {
          summary: 'Generate UPI intent URI',
          requestBody: {
            required: true,
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    amount: { type: 'number' },
                    upiId: { type: 'string' },
                    purpose: { type: 'string' }
                  },
                  required: ['amount', 'upiId', 'purpose']
                }
              }
            }
          },
          responses: {
            '200': {
              description: 'UPI link generated',
              content: {
                'application/json': {
                  schema: {
                    type: 'object',
                    properties: {
                      uri: { type: 'string' },
                      qr: { type: 'string', description: 'Base64 PNG' }
                    }
                  }
                }
              }
            }
          }
        }
      },
      '/api/paypal/webhook': {
        post: {
          summary: 'PayPal webhook listener',
          responses: {
            '200': {
              description: 'Webhook processed'
            }
          }
        }
      }
    }
  };

  return NextResponse.json(openapi);
}
