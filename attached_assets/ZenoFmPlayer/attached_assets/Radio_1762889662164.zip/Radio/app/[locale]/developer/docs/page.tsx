import Link from 'next/link';
import { AccentButton } from '@/components/AccentButton';
import { SectionHeading } from '@/components/SectionHeading';

export default function DeveloperDocsPage() {
  return (
    <div className="space-y-16">
      <section className="rounded-3xl border border-cosmic-muted/40 bg-cosmic-surface/40 p-10">
        <h1 className="text-4xl font-semibold text-white">Developer Docs</h1>
        <p className="mt-3 max-w-3xl text-sm text-cosmic-text/60">
          Integrate AstroKalki into your product. Use our OpenAPI schema to issue consultations, generate karma reports, and
          reconcile PayPal or UPI payments.
        </p>
        <div className="mt-6 flex flex-wrap gap-4">
          <AccentButton asChild>
            <Link href="openapi.json">Download OpenAPI</Link>
          </AccentButton>
          <AccentButton variant="outline" asChild>
            <Link href="mailto:dev@astrokalki.com">Contact platform team</Link>
          </AccentButton>
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Endpoints" title="Core API" />
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {[
            {
              method: 'POST',
              path: '/api/paypal/create-order',
              description: 'Create a PayPal order for premium karma tools.'
            },
            {
              method: 'POST',
              path: '/api/paypal/webhook',
              description: 'Receive PayPal capture notifications to activate tokens.'
            },
            {
              method: 'POST',
              path: '/api/upi/create-intent',
              description: 'Generate a UPI deep link and QR for manual verification.'
            }
          ].map((endpoint) => (
            <div key={endpoint.path} className="card-surface p-6">
              <span className="rounded-full border border-cosmic-copper/60 px-3 py-1 text-xs text-cosmic-copper">
                {endpoint.method}
              </span>
              <p className="mt-3 text-lg font-semibold text-white">{endpoint.path}</p>
              <p className="mt-2 text-sm text-cosmic-text/60">{endpoint.description}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="card-surface p-10">
        <h2 className="text-2xl font-semibold text-white">Webhook verification</h2>
        <p className="mt-2 text-sm text-cosmic-text/60">
          Set the webhook secret in Supabase config. Failed verifications remain in the audit log so your devops team can
          reprocess.
        </p>
      </section>
    </div>
  );
}
