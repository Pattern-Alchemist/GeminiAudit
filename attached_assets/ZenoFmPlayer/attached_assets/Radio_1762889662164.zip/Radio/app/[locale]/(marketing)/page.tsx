import { AccentButton } from '@/components/AccentButton';
import { EpisodeCard } from '@/components/EpisodeCard';
import { KarmaLeadForm } from '@/components/KarmaLeadForm';
import { SectionHeading } from '@/components/SectionHeading';
import { ToolCard } from '@/components/ToolCard';
import { useMessages, useTranslations } from 'next-intl';
import { Sparkles, Radio, Infinity, Layers, FileAudio, FileText } from 'lucide-react';

const testimonials = [
  {
    quote:
      '“My deeds finally made sense. The Karma Ledger PDF mapped exactly where my energy was leaking.”',
    name: 'Sahana M.',
    role: 'Dharma+ Member'
  },
  {
    quote:
      '“Consultations felt like a spiritual strategy session. No fluff, only karma and action.”',
    name: 'Rohit A.',
    role: 'Seeker Plan'
  },
  {
    quote: '“The radio archive keeps me aligned daily. It’s my aurora soundtrack.”',
    name: 'Leela G.',
    role: 'Starter Plan'
  }
];

const episodes = [
  {
    title: 'Aurora Rituals for Renewal',
    description: 'Nightly practices to rebalance karmic output and invite dharma focus.',
    duration: '28 min',
    tags: ['rituals', 'aurora']
  },
  {
    title: 'Ledger vs. Horoscope',
    description: 'Why karma ledgers unlock deeper agency than daily horoscopes.',
    duration: '32 min',
    tags: ['karma', 'strategy']
  },
  {
    title: 'UPI as Sacred Energy Exchange',
    description: 'Blending modern payments with ancestral gratitude.',
    duration: '24 min',
    tags: ['payments', 'gratitude']
  }
];

export default function MarketingPage() {
  const t = useTranslations();
  const messages = useMessages();
  const freeTools = (messages.freeTools?.tools ?? []) as Array<{ name: string; description: string }>;
  const paidTools = (messages.paidTools?.tools ?? []) as Array<{
    name: string;
    description: string;
    price: string;
    format: string;
  }>;
  const pricingPlans = (messages.pricing?.plans ?? []) as Array<{ name: string; price: string; features: string[] }>;
  const faqItems = (messages.faq?.items ?? []) as Array<{ question: string; answer: string }>;

  return (
    <div className="space-y-24">
      <section className="relative overflow-hidden rounded-3xl border border-cosmic-muted/50 bg-gradient-to-br from-[#0D111C] to-[#05080E] p-12">
        <div className="absolute right-[-4rem] top-[-4rem] h-64 w-64 rounded-full bg-cosmic-copper/20 blur-3xl" />
        <div className="absolute bottom-[-3rem] left-[-6rem] h-72 w-72 rounded-full bg-cosmic-aurora/10 blur-3xl" />
        <div className="relative grid gap-12 md:grid-cols-[3fr_2fr]">
          <div className="space-y-8">
            <span className="badge text-cosmic-aurora">{t('marketing.karmaFirstTitle')}</span>
            <h1 className="text-5xl font-semibold text-white md:text-6xl">{t('marketing.heroTitle')}</h1>
            <p className="max-w-2xl text-lg text-cosmic-text/70">{t('marketing.heroSubtitle')}</p>
            <div className="flex flex-wrap gap-4">
              <AccentButton>{t('marketing.primaryCta')}</AccentButton>
              <AccentButton variant="outline">{t('marketing.secondaryCta')}</AccentButton>
            </div>
            <div className="grid gap-6 pt-6 md:grid-cols-3">
              {[{ icon: Sparkles, label: 'Karma-first insights' }, { icon: Radio, label: 'Radio immersion' }, { icon: Infinity, label: 'Dharma accountability' }].map((feature) => (
                <div key={feature.label} className="card-surface p-4">
                  <feature.icon className="mb-3 h-5 w-5 text-cosmic-copper" />
                  <p className="text-sm text-cosmic-text/70">{feature.label}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="card-surface relative p-6">
            <div className="absolute right-6 top-6 rounded-full bg-cosmic-muted/50 px-3 py-1 text-xs uppercase tracking-[0.2em] text-cosmic-text/60">
              Free tools
            </div>
            <h3 className="text-2xl font-semibold text-white">{t('marketing.primaryCta')}</h3>
            <p className="mt-2 text-sm text-cosmic-text/60">{t('freeTools.lead')}</p>
            <KarmaLeadForm />
          </div>
        </div>
      </section>

      <section>
        <SectionHeading
          eyebrow="Process"
          title={t('marketing.karmaFirstTitle')}
          description={t('marketing.karmaFirstDescription')}
        />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {['Survey your deeds', 'Decode karmic signals', 'Align dharmic action'].map((step, index) => (
            <div key={step} className="card-surface p-6">
              <span className="text-sm text-cosmic-copper">Step 0{index + 1}</span>
              <p className="mt-3 text-lg font-semibold text-white">{step}</p>
              <p className="mt-2 text-sm text-cosmic-text/60">
                We map your actions, relationships, and rituals to reveal the ledger that guides the next 90 days.
              </p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Broadcast" title={t('marketing.episodesTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {episodes.map((episode) => (
            <EpisodeCard key={episode.title} {...episode} />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Lead magnets" title={t('marketing.freeToolsTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {freeTools.map((tool) => (
            <ToolCard
              key={tool.name}
              name={tool.name}
              description={tool.description}
              cta={t('marketing.primaryCta')}
              icon={Layers}
              accent="free"
              badge="Free"
              footer={<p className="text-xs text-cosmic-text/60">Instant insight delivered via email.</p>}
            />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Premium" title={t('marketing.paidToolsTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {paidTools.map((tool) => (
            <ToolCard
              key={tool.name}
              name={tool.name}
              description={`${tool.description} • ${tool.format}`}
              cta="Purchase"
              icon={tool.format.includes('Audio') ? FileAudio : FileText}
              accent="paid"
              price={tool.price}
              footer={<p className="text-xs text-cosmic-text/60">Checkout via PayPal or UPI.</p>}
            />
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Transformation" title={t('marketing.testimonialsTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {testimonials.map((testimonial) => (
            <div key={testimonial.name} className="card-surface p-6">
              <p className="text-base text-cosmic-text/70">{testimonial.quote}</p>
              <p className="mt-4 text-sm font-semibold text-white">{testimonial.name}</p>
              <p className="text-xs text-cosmic-text/50">{testimonial.role}</p>
            </div>
          ))}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Pricing" title={t('marketing.pricingTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {pricingPlans.map((plan, index) => (
              <div
                key={plan.name}
                className={
                  'card-surface flex h-full flex-col justify-between p-6' +
                  (index === 1 ? ' border border-cosmic-copper shadow-glow' : '')
                }
              >
                <div className="space-y-4">
                  <h3 className="text-2xl font-semibold text-white">{plan.name}</h3>
                  <p className="text-lg font-semibold text-cosmic-copper">{plan.price}</p>
                  <ul className="space-y-2 text-sm text-cosmic-text/70">
                    {plan.features.map((feature) => (
                      <li key={feature}>• {feature}</li>
                    ))}
                  </ul>
                </div>
                <AccentButton className="mt-6 w-full">{t('pricing.cta')}</AccentButton>
              </div>
            )
          )}
        </div>
      </section>

      <section>
        <SectionHeading eyebrow="Answers" title={t('marketing.faqTitle')} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {faqItems.map((item) => (
            <div key={item.question} className="card-surface p-6">
              <h3 className="text-lg font-semibold text-white">{item.question}</h3>
              <p className="mt-2 text-sm text-cosmic-text/70">{item.answer}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
