import { NextResponse } from 'next/server';
import { z } from 'zod';
import { createConsultationLink } from '@/lib/scheduling';

const bodySchema = z.object({
  tier: z.enum(['flash-q', 'karma-decode', 'dharma-alignment']),
  name: z.string().min(2),
  email: z.string().email()
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = bodySchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid payload', details: parsed.error.flatten() }, { status: 400 });
    }

    const link = createConsultationLink(parsed.data);
    if (!link) {
      return NextResponse.json(
        { error: 'Integration disabled: Cal.com missing key' },
        { status: 503 }
      );
    }

    return NextResponse.json({ bookingLink: link });
  } catch (error) {
    return NextResponse.json({ error: 'Unable to schedule consultation', details: String(error) }, { status: 500 });
  }
}
