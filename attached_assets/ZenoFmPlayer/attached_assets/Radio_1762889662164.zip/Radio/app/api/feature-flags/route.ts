import { NextResponse } from 'next/server';
import { getServerSupabase } from '@/lib/supabase';
import { requireAdmin } from '@/lib/auth';

export async function GET() {
  try {
    const supabase = getServerSupabase();

    const { data, error } = await supabase
      .from('feature_flags')
      .select('key, enabled, meta')
      .order('key');

    if (error) throw error;

    const flags = data.reduce((acc: Record<string, { enabled: boolean; meta: any }>, flag: any) => {
      acc[flag.key] = {
        enabled: flag.enabled,
        meta: flag.meta
      };
      return acc;
    }, {} as Record<string, { enabled: boolean; meta: any }>);

    return NextResponse.json({ flags });
  } catch (error) {
    console.error('Error fetching feature flags:', error);
    return NextResponse.json({ flags: {} }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    await requireAdmin();

    const supabase = getServerSupabase();
    const { key, enabled } = await request.json();

    if (!key || typeof enabled !== 'boolean') {
      return NextResponse.json(
        { error: 'Invalid request' },
        { status: 400 }
      );
    }

    const { data, error } = await supabase
      .from('feature_flags')
      .update({ enabled, updated_at: new Date().toISOString() })
      .eq('key', key)
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ flag: data });
  } catch (error) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    if (error instanceof Error && error.message.startsWith('Forbidden')) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }
    console.error('Error updating feature flag:', error);
    return NextResponse.json(
      { error: 'Failed to update feature flag' },
      { status: 500 }
    );
  }
}
