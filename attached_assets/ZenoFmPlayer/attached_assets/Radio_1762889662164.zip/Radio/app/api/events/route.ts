import { NextResponse } from 'next/server';
import { getServerSupabase } from '@/lib/supabase';
import { requireAuth, getAuthenticatedUser } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const user = await requireAuth();
    const body = await request.json();
    const { event_type, data } = body;

    if (!event_type) {
      return NextResponse.json(
        { error: 'event_type is required' },
        { status: 400 }
      );
    }

    const supabase = getServerSupabase();

    const { data: eventData, error } = await supabase
      .from('events')
      .insert({
        user_id: user.id,
        event_type,
        data: data || {}
      })
      .select()
      .single();

    if (error) throw error;

    return NextResponse.json({ success: true, event: eventData });

  } catch (error) {
    if (error instanceof Error && error.message === 'Unauthorized') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }
    console.error('Events API error:', error);
    return NextResponse.json(
      { error: 'Failed to log event' },
      { status: 500 }
    );
  }
}

export async function GET(request: Request) {
  try {
    const user = await getAuthenticatedUser();
    
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const event_type = searchParams.get('event_type');
    const limit = parseInt(searchParams.get('limit') || '50');

    const supabase = getServerSupabase();

    const { data: profile } = await supabase
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    const isAdmin = profile?.role === 'admin';

    let query = supabase
      .from('events')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (!isAdmin) {
      query = query.eq('user_id', user.id);
    }

    if (event_type) {
      query = query.eq('event_type', event_type);
    }

    const { data, error } = await query;

    if (error) throw error;

    return NextResponse.json({ events: data || [] });

  } catch (error) {
    console.error('Events GET error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch events' },
      { status: 500 }
    );
  }
}
