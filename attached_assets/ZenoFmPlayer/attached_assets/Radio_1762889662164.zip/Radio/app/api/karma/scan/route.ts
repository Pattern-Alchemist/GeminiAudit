import { NextResponse } from 'next/server';
import { runKarmaTool, type KarmaInput } from '@/lib/karma-engine';
import { getServerSupabase } from '@/lib/supabase';
import { getAuthenticatedUser } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const user = await getAuthenticatedUser();
    
    if (!user) {
      return NextResponse.json(
        { error: 'Authentication required' },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { birthDate, birthTime, birthPlace, timezone } = body;

    if (!birthDate || !birthTime || !birthPlace) {
      return NextResponse.json(
        { error: 'Missing required birth data' },
        { status: 400 }
      );
    }

    const input: KarmaInput = {
      birthDate,
      birthTime,
      birthPlace,
      timezone: timezone || 'UTC'
    };

    const result = await runKarmaTool('scan', input);

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Failed to generate scan' },
        { status: 500 }
      );
    }

    const supabase = getServerSupabase();
    
    await supabase.from('karma_reads').insert({
      user_id: user.id,
      tool_slug: 'scan',
      input_data: input,
      output_data: result.data,
      metadata: {
        cached: result.cached,
        demoMode: result.demoMode
      }
    });

    await supabase.from('events').insert({
      user_id: user.id,
      event_type: 'tool_used',
      data: {
        tool: 'scan',
        demoMode: result.demoMode
      }
    });

    return NextResponse.json({
      success: true,
      data: result.data,
      cached: result.cached,
      demoMode: result.demoMode
    });

  } catch (error) {
    console.error('QuickScan error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
