import { NextResponse } from 'next/server';
import { getServerSupabase } from '@/lib/supabase';
import { getAuthenticatedUser } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const user = await getAuthenticatedUser();
    const supabase = getServerSupabase();

    const defaultPulse = {
      do: [
        'Complete one unfinished task from the past',
        'Practice 10 minutes of gratitude meditation',
        'Review your current karmic patterns'
      ],
      avoid: [
        'Starting new commitments before finishing old ones',
        'Making major decisions today',
        'Overcommitting your energy'
      ],
      connect: 'Reach out to someone you haven\'t spoken to in a while'
    };

    let streak = 0;
    let recentReads: any[] = [];

    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('streak_days')
        .eq('id', user.id)
        .single();

      if (profile) {
        streak = profile.streak_days || 0;
      }

      const { data: reads } = await supabase
        .from('karma_reads')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(5);

      recentReads = reads || [];
    }

    return NextResponse.json({
      pulse: defaultPulse,
      streak,
      impactWindows: [],
      recentReads
    });

  } catch (error) {
    console.error('Dashboard API error:', error);
    return NextResponse.json(
      { error: 'Failed to load dashboard' },
      { status: 500 }
    );
  }
}
