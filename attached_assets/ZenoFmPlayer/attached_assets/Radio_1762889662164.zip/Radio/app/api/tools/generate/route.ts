import { NextResponse } from 'next/server';
import { z } from 'zod';
import { generateToolResponse } from '@/lib/llm';
import { getOpenRouterConfig, getGeminiConfig } from '@/lib/env';

const bodySchema = z.object({
  tool: z.enum(['karma-ledger', 'dharma-path', 'destiny-window']),
  prompt: z.string().min(10)
});

export async function POST(request: Request) {
  const openrouter = getOpenRouterConfig();
  const gemini = getGeminiConfig();

  if (!openrouter.enabled && !gemini.enabled) {
    return NextResponse.json(
      { error: 'Integration disabled: LLM missing key' },
      { status: 503 }
    );
  }

  try {
    const body = await request.json();
    const parsed = bodySchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid payload', details: parsed.error.flatten() }, { status: 400 });
    }

    const result = await generateToolResponse(parsed.data);
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: 'Unable to generate tool output', details: String(error) }, { status: 500 });
  }
}
