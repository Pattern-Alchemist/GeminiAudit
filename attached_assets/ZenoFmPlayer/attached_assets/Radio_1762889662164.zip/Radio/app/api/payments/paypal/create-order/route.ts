import { NextResponse } from 'next/server';
import { PayPalOrderSchema, logPaymentAttempt } from '@/lib/payments';
import { getPaymentConfiguration } from '@/lib/env';

export async function POST(request: Request) {
  const config = getPaymentConfiguration();

  if (!config.paypalUrl) {
    return NextResponse.json(
      { error: 'Integration disabled: PayPal missing key' },
      { status: 503 }
    );
  }

  try {
    const body = await request.json();
    const parsed = PayPalOrderSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid payload', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const fakeOrderId = `ASTRO-${Date.now()}`;

    logPaymentAttempt({
      channel: 'paypal',
      reference: fakeOrderId,
      amount: Number(parsed.data.purchase_units[0]?.amount.value ?? '0'),
      currency: parsed.data.purchase_units[0]?.amount.currency_code ?? 'USD',
      status: 'initiated'
    });

    return NextResponse.json({
      id: fakeOrderId,
      approvalUrl: config.paypalUrl
    });
  } catch (error) {
    return NextResponse.json({ error: 'Unable to create order', details: String(error) }, { status: 500 });
  }
}
