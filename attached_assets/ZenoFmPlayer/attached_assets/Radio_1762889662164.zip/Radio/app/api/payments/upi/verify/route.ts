import { NextResponse } from 'next/server';
import { logPaymentAttempt } from '@/lib/payments';

export async function POST(request: Request) {
  try {
    const body = await request.json();

    logPaymentAttempt({
      channel: 'upi',
      reference: body.reference ?? 'unknown',
      amount: Number(body.amount ?? 0),
      currency: body.currency ?? 'INR',
      status: body.status ?? 'verification-request',
      payload: body
    });

    return NextResponse.json({ verified: true });
  } catch (error) {
    return NextResponse.json({ error: 'Unable to verify UPI payment', details: String(error) }, { status: 500 });
  }
}
