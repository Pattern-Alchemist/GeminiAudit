import { NextResponse } from 'next/server';
import { logPaymentAttempt } from '@/lib/payments';

export async function POST(request: Request) {
  try {
    const body = await request.json();

    logPaymentAttempt({
      channel: 'paypal',
      reference: body.id ?? 'unknown',
      amount: Number(body.purchase_units?.[0]?.amount?.value ?? 0),
      currency: body.purchase_units?.[0]?.amount?.currency_code ?? 'USD',
      status: body.status ?? 'webhook-received',
      payload: body
    });

    return NextResponse.json({ received: true });
  } catch (error) {
    return NextResponse.json({ error: 'Unable to process webhook', details: String(error) }, { status: 500 });
  }
}
