import { NextResponse } from 'next/server';
import { UpiIntentSchema, buildUpiUri, logPaymentAttempt } from '@/lib/payments';
import { getPaymentConfiguration } from '@/lib/env';

export async function POST(request: Request) {
  const config = getPaymentConfiguration();

  if (!config.upiId) {
    return NextResponse.json(
      { error: 'Integration disabled: UPI missing key' },
      { status: 503 }
    );
  }

  try {
    const body = await request.json();
    const parsed = UpiIntentSchema.safeParse({ ...body, upiId: config.upiId });

    if (!parsed.success) {
      return NextResponse.json(
        { error: 'Invalid payload', details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const intent = parsed.data;
    const upiUri = buildUpiUri(intent);

    logPaymentAttempt({
      channel: 'upi',
      reference: intent.purpose,
      amount: intent.amount,
      currency: intent.currency,
      status: 'initiated'
    });

    return NextResponse.json({ upiUri });
  } catch (error) {
    return NextResponse.json({ error: 'Unable to create UPI intent', details: String(error) }, { status: 500 });
  }
}
