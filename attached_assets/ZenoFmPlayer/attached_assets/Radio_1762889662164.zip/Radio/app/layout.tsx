import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'AstroKalki — Decode Karma. Align Dharma.',
  description:
    'AstroKalki is a karma-first spiritual tech platform offering high-conversion consultations and deep tools with Supabase multi-tenancy.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
