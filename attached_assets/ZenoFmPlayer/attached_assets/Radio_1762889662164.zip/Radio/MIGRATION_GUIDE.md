# Karma Engine Database Migration Guide

## Migration Status

Created: `supabase/migrations/0002_karma_engine.sql`
Status: ✅ Ready for deployment (security reviewed)

## What This Migration Does

Adds the complete Karma Engine schema:
- ✅ 5 core Karma tools (DNA, Debts, Impacts, Radar, Bond)
- ✅ Feature flags system
- ✅ Events tracking & analytics
- ✅ Reports & PDF exports
- ✅ Courses, Products, Orders (feature-flagged)
- ✅ Client intake profiles
- ✅ Deterministic copy tables
- ✅ Secure RLS policies with admin access
- ✅ Streak tracking automation

## How to Apply This Migration

### Option 1: Supabase Dashboard (Recommended)

1. Go to your Supabase project dashboard
2. Navigate to **SQL Editor**
3. Create a new query
4. Copy and paste the contents of `supabase/migrations/0002_karma_engine.sql`
5. Click **Run** to execute the migration
6. Verify success in the **Table Editor**

### Option 2: Supabase CLI

```bash
# Install Supabase CLI if not already installed
npm install -g supabase

# Link your project
supabase link --project-ref YOUR_PROJECT_REF

# Apply the migration
supabase db push
```

## Verification Checklist

After running the migration, verify these tables exist:

- [ ] `feature_flags`
- [ ] `karma_reads`
- [ ] `events`
- [ ] `copy_tables`
- [ ] `reports`
- [ ] `courses` & `course_lessons`
- [ ] `products` & `inventory`
- [ ] `orders`
- [ ] `client_profiles`
- [ ] `enrollments`

Check that `profiles` table has new columns:
- [ ] `role` (default: 'user')
- [ ] `streak_days` (default: 0)
- [ ] `last_pulse_at`
- [ ] `birth_date`, `birth_time`, `birth_place`, `timezone`

## Security Notes

✅ All RLS policies reviewed and secured
✅ Admins can manage content via `/admin` dashboard
✅ Users can only see their own karma reads, reports, and orders
✅ Shared reports use secure token-based access
✅ Search path hijacking protection in place

## Next Steps

1. Apply this migration to your Supabase database
2. Feature flags system will be ready to use
3. Start building Karma Engine tools (DNA, Debts, etc.)
