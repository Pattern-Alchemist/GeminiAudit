import { getRequestConfig } from 'next-intl/server';
import { defaultLocale, isLocale } from './config';

export default getRequestConfig(async ({ requestLocale }) => {
  const locale = isLocale(requestLocale || '') ? requestLocale! : defaultLocale;
  return {
    locale,
    messages: (await import(`./messages/${locale}.ts`)).default
  };
});
