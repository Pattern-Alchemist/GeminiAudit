const messages = {
  navigation: {
    home: 'Home',
    dashboard: 'Dashboard',
    radio: 'Radio',
    tools: 'Tools',
    consultations: 'Consultations',
    billing: 'Billing',
    admin: 'Admin',
    docs: 'Developer'
  },
  marketing: {
    heroTitle: 'Decode Karma. Align Dharma.',
    heroSubtitle:
      'AstroKalki is the spiritual-tech cockpit where your deeds become the interface for destiny. We decode your karmic signatures and help you align with dharmic action.',
    primaryCta: 'Start Free Karma Scan',
    secondaryCta: 'Book Consultation',
    karmaFirstTitle: 'Karma-first Astrology',
    karmaFirstDescription:
      'Planets reveal patterns; karma sets priorities. Our guides translate your lived actions into a dharmic roadmap.',
    episodesTitle: 'Audio & Radio Episodes',
    freeToolsTitle: 'Free Karma Tools',
    paidToolsTitle: 'Premium Deep Tools',
    testimonialsTitle: 'Voices from the Dharma Path',
    pricingTitle: 'Choose Your Dharma Tier',
    faqTitle: 'Frequently Asked Karma Queries'
  },
  freeTools: {
    lead: 'Access any free tool to receive a personalized karma insight via email.',
    tools: [
      {
        name: 'Karma Pulse',
        description: 'A quick pulse-check on your karmic energy over the next 7 days.'
      },
      {
        name: 'Compatibility Snapshot',
        description: 'Decode relational karma across work, love, and collaboration.'
      },
      {
        name: '7-Day Destiny Window',
        description: 'A tailored guide for dharmic action over the coming week.'
      }
    ]
  },
  paidTools: {
    tools: [
      {
        name: 'Karma Ledger Report',
        format: 'PDF',
        price: '$79',
        description: '90-day karmic ledger that details your energetic inflow & outflow with practical rituals.'
      },
      {
        name: 'Dharma Path Reading',
        format: 'Audio',
        price: '$129',
        description: 'A narrated immersion to align your dharmic path with specific practices.'
      },
      {
        name: 'Karma Detox Routine',
        format: 'PDF + Audio',
        price: '$99',
        description: 'Integrated cleanse plan balancing actions, mantra, and mindful rest.'
      }
    ]
  },
  consultations: {
    plans: [
      {
        name: 'Flash Q',
        price: '$49',
        description: '15-minute dharma hotline for urgent karmic clarity.'
      },
      {
        name: 'Karma Decode',
        price: '$149',
        description: '60-minute session with ledger deep-dive and actionable karma actions.'
      },
      {
        name: 'Dharma Alignment',
        price: '$249',
        description: '90-minute strategic dharma alignment with accountability rituals.'
      }
    ],
    cta: 'Reserve Session'
  },
  pricing: {
    plans: [
      {
        name: 'Starter',
        price: '$19/mo',
        features: [
          'Monthly Karma Pulse updates',
          'Invite to live radio episodes',
          'Access to aurora meditations'
        ]
      },
      {
        name: 'Seeker',
        price: '$49/mo',
        features: [
          'Everything in Starter',
          'Quarterly Karma Ledger PDF',
          'Priority consultation booking'
        ]
      },
      {
        name: 'Dharma+',
        price: '$99/mo',
        features: [
          'Dedicated dharma coach',
          'Unlimited radio archive',
          'Monthly detox routine refresh'
        ]
      }
    ],
    cta: 'Activate Tier'
  },
  faq: {
    items: [
      {
        question: 'Is AstroKalki a horoscope service?',
        answer:
          'No. We decode karma and dharma patterns to design practical action plans aligned with your spiritual goals.'
      },
      {
        question: 'How do payments work?',
        answer:
          'Pay securely via PayPal or any UPI app. After confirmation we activate your tokenized access in the dashboard.'
      },
      {
        question: 'Do I need birth details?',
        answer:
          'Optional. We can work with karmic pattern surveys and your action history if you prefer a non-astrological approach.'
      }
    ]
  },
  dashboard: {
    title: 'Your Karma Control Center',
    freeTools: 'Free Karma Tools',
    purchasedTools: 'Purchased Deep Tools',
    consultations: 'Upcoming Consultations',
    episodes: 'Radio Episodes',
    receipts: 'Recent Payments & Tokens',
    upsellTitle: 'Amplify Your Dharma',
    upsellDescription: 'Upgrade to the Karma Ledger PDF or book a live consult to transform insights into aligned action.',
    ledgerCta: 'Get 90-day Karma Ledger',
    consultCta: 'Book Dharma Consult'
  },
  billing: {
    eyebrow: 'Billing & Tokens',
    title: 'Payments and Energy Exchange',
    intro: 'Choose your trusted payment channel to activate deep karma tools and consultations.',
    paypalDescription: 'Use PayPal Checkout for international cards and instant confirmation.',
    paypalCta: 'Open PayPal Portal',
    paypalDisabled: 'PayPal unavailable — contact support',
    upiDescription: 'Scan or tap to send energy via UPI. Include your email in the note.',
    upiHint: 'After sending, upload the reference ID for token activation.',
    upiDisabled: 'UPI unavailable — contact support'
  },
  admin: {
    title: 'Admin Command Deck',
    subtitle: 'Manage episodes, tools, consultations, payments, and branding.',
    approve: 'Approve',
    reject: 'Reject',
    markPaid: 'Mark as Paid'
  },
  forms: {
    email: 'Email',
    name: 'Full Name',
    submit: 'Submit',
    success: 'We have received your request. Check your inbox within minutes.'
  }
};

export default messages;
