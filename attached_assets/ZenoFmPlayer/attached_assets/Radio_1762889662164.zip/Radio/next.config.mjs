import nextIntl from 'next-intl/plugin';

const withNextIntl = nextIntl('./i18n/request.ts');

const nextConfig = withNextIntl({});

export default nextConfig;
