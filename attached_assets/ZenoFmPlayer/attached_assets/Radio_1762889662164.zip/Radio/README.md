# AstroKalki

AstroKalki is a karma-first spiritual tech platform built with Next.js 14, Tailwind, shadcn-inspired components, and Supabase.
It provides free karma lead magnets, premium digital tools, consultations, and radio episodes with PayPal + UPI payments.

## Stack

- Next.js 14 (App Router, TypeScript)
- Tailwind CSS with cosmic copper palette
- shadcn/ui-inspired component primitives using Radix
- Supabase Postgres with RLS for multi-tenant orgs and audit log
- PayPal + UPI payment flows
- next-intl for `en` and `hi`

## Getting Started

```bash
npm install
npm run dev
```

Duplicate `.env.example` to `.env.local` and customize values for Supabase, AI, calendar, email, LiveKit, and payments. Missing
keys do not crash the app but surface a banner so you can prioritize integration work.

Run the Supabase SQL migration:

```bash
supabase db push --file supabase/migrations/0001_init.sql
```

Generate the OpenAPI schema for offline use:

```bash
pnpm run generate:openapi
```

## Project Layout

- `app/[locale]/(marketing)` — high-conversion marketing site with hero, tools, pricing, FAQ
- `app/[locale]/app` — logged-in dashboard with reports, consultations, and receipts
- `app/[locale]/radio` — radio archive with glassmorphic player
- `app/[locale]/tools` — free and premium tool catalog
- `app/[locale]/consultations` — consultation tiers and booking flow
- `app/[locale]/admin` — admin tables for media, tools, payments, and branding controls
- `app/[locale]/developer` — OpenAPI JSON + docs
- `app/api` — PayPal, UPI, tool generation, and consultation integrations

## Payments

- PayPal: `/api/payments/paypal/create-order` for initiating approvals and `/api/payments/paypal/webhook` to capture events.
- UPI: `/api/payments/upi/create-intent` returns the deep link for manual approval; `/api/payments/upi/verify` logs follow-up sta
tus.
- Tool generation: `/api/tools/generate` uses OpenRouter or Gemini keys when available.
- Consultations: `/api/consultations/schedule` and `/api/consultations/livekit` wire Cal.com + LiveKit flows.

## i18n

Routes are locale aware using `next-intl`. Default locale is `en` with `hi` translations included.

## Branding

- Accent: Cosmic copper / warm gold for CTAs and highlights
- Base: Deep space blue/near-black backgrounds
- Highlights: Aurora teal for secondary cues

## Missing Keys

If any integration credentials are absent the UI surfaces a banner and related API routes respond with informative messages so yo
u can continue building without downtime. Configure environment variables before deploying.

## Tests

All automated checks are available through npm scripts:

```bash
npm run lint
npm run test      # Vitest unit suite
npm run test:e2e  # Playwright smoke tests (skips when browsers unavailable)
npm run test:a11y # Axe assertions on representative markup
```
